<?php

function _test_public_methods(reflectionClass $rc,
                              $methods = array())
{
    $pms = $rc->getMethods(ReflectionMethod::IS_PUBLIC);

    if (count($pms) < (count($methods) + 2))
    {
        trigger_error("Public methods count not consistent!", E_USER_NOTICE);
    }

    foreach ($methods as $method_name)
    {
        $cm = $rc->getMethod($method_name);

        if (($cm->getDeclaringClass()->name != $rc->name)
            || !$cm->isPublic())
        {
            trigger_error("Public method '" . $method_name . "' not declared in '" . $rc->name . "'!", E_USER_WARNING);
        }
    }

    return true;
}

function _test_private_methods(reflectionClass $rc,
                               $methods = array())
{
    $pms = $rc->getMethods(ReflectionMethod::IS_PRIVATE);

    foreach ($methods as $method_name)
    {
        $cm = $rc->getMethod($method_name);

        if (($cm->getDeclaringClass()->name != $rc->name)
            || !$cm->isPrivate())
        {
            trigger_error("Private method '" . $method_name . "' not declared in '" . $rc->name . "'!", E_USER_WARNING);
        }
    }

    return true;
}

function test_abstract_class($class_name,
                             $public_methods = array(),
                             $private_methods = array())
{
    $rc = new reflectionClass($class_name);

    $name_components = explode('_', $class_name);

    return ((basename($rc->getFilename()) == $class_name . '.php')
        && $rc->implementsInterface($name_components[0])
        && $rc->isAbstract()
        && !$rc->isInstantiable()
        && _test_public_methods($rc, $public_methods)
        && _test_private_methods($rc, $private_methods));
}

function test_class($class_name,
                    $public_methods = array(),
                    $private_methods = array())
{
    $rc = new reflectionClass($class_name);

    $name_components = explode('_', $class_name);
    array_pop($name_components);
    $parent_class = implode('_', $name_components);

    return ((basename($rc->getFilename()) == $class_name . '.php')
        && $rc->isSubclassOf($parent_class)
        && !$rc->isAbstract()
        && $rc->isInstantiable()
        && _test_public_methods($rc, $public_methods)
        && _test_private_methods($rc, $private_methods));
}

?>