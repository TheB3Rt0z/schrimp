<?php

// defining configuration and required constants

define('MAIN_CONFIG', 'configuration.cfg');

if (file_exists(MAIN_CONFIG))
{
    if (is_readable(MAIN_CONFIG))
    {
        eval("\$configuration = array(" . file_get_contents(MAIN_CONFIG) . ");");
    }
    else
    {
        trigger_error("Main configuration file not readable!", E_USER_WARNING);
    }
}
else
{
    trigger_error("Main configuration file not found!", E_USER_ERROR);
}

foreach ($configuration['required_paths'] as $key => $values)
{
    if (!empty($values['path']))
    {
        define(strtoupper($values['path']) . '_PATH', $values['path'] . "/");
    }
    else
    {
        trigger_error("Path not specified for config key 'required_paths/" . $key . "'!", E_USER_WARNING);
    }

    if (empty($values['abstract']))
    {
        trigger_error("Abstract not specified for config key 'required_paths/" . $key . "'!", E_USER_NOTICE);
    }

    if (empty($values['description']))
    {
        trigger_error("Description not specified for config key 'required_paths/" . $key . "'!", E_USER_NOTICE);
    }
}

if ($_SERVER['HTTP_HOST'] == "localhost")
{
    $custom_configuration = $configuration['local_settings'];
}
else
{
    $custom_configuration = $configuration['online_settings'];
}

function create_constant($value, $key, $custom)
{
    if (!is_array($value))
    {
        if (array_key_exists($key, $custom))
        {
            $value = $custom[$key];
        }
        define(strtoupper($key), $value);
    }
}
array_walk_recursive($configuration['core_settings'], 'create_constant', $custom_configuration);

if (AUTO_TEST)
{
    require_once('tests.php');
}


// loading main libraries (core directory) and creating aliases

if (file_exists(CORE_PATH)
    && is_dir(CORE_PATH))
{
    if ($directory_handle = opendir(CORE_PATH))
    {
        $files_list = array();

        while ($file_name = readdir($directory_handle))
        {
            if (is_file($file_path = CORE_PATH . $file_name))
            {
                $files_list[] = $file_name;
            }
        }

        function compare_length($a, $b)
        {
            return strlen($a) > strlen($b);
        }
        usort($files_list, 'compare_length');

        $abstract_classes = array();

        $classes = array();

        foreach ($files_list as $file_name)
        {
            include_once(CORE_PATH . $file_name);

            $path_length = strlen(CORE_PATH) - 1;
            $class_name = substr($file_name, 0, -$path_length);
            $alias_name = substr(array_pop(explode("_", $file_name)), 0, -$path_length);

            $rc = new ReflectionClass($class_name);

            if (!$rc->isInterface())
            {
                $auto_test_check = false;

                foreach ($rc->getMethods() as $key => $method)
                {
                    if ($method->name == 'auto_test'
                        && $method->getDeclaringClass() == $rc)
                    {
                        $auto_test_check = true;
                    }
                }

                if (!$auto_test_check)
                {
                    trigger_error("Unable to test class '" . $class_name . "'!", E_USER_NOTICE);
                }

                if (!$rc->isAbstract())
                {
                    if (!class_alias($class_name, $alias_name))
                    {
                        trigger_error("Unable to create alias '" . $alias_name . "' from class '" . $class_name . "'!", E_USER_WARNING);
                    }

                    $classes[] = $class_name;
                }
                else
                {
                    $abstract_classes[] = $class_name;
                }
            }
        }

        if (AUTO_TEST)
        {
            foreach ($abstract_classes as $class_name)
            {
                if (!$class_name::auto_test())
                {
                    trigger_error("Autotest failed for abstract class '" . $class_name . "'!", E_USER_WARNING);
                }
            }

            foreach ($classes as $class_name)
            {
                $tc = new $class_name;

                if (!$tc->auto_test())
                {
                    trigger_error("Autotest failed for class '" . $class_name . "'!", E_USER_WARNING);
                }
            }
        }
    }
    else
    {
        trigger_error("Core directory isn't accessible!", E_USER_ERROR);
    }
}
else
{
    trigger_error("Core directory doesn't exists!", E_USER_ERROR);
}

?>