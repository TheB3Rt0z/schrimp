<?php

include("main.php");

define("TEST_CONTENT", "Hello world! 8-P");

//var_dump(get_defined_vars());
//var_dump(get_defined_function());

//print_r(get_declared_classes());

//var_dump(get_loaded_extensions());

?>

<html>
    <head>
        <title>Toolbox Framework Tests</title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <body>
        <table>
            <tr valign="top">
                <td>
                    XHTML Interface Tests
                    <br /><br />
                    > <b>Rendering xhtml</b>: <?php /*html::render();*/ ?> NOT POSSIBLE (INTERFACE)
                    <br /><br />
                    > <b>Rendering xhtml_tag</b>: <?php /*tag::render();*/ ?> NOT POSSIBLE (ABSTRACT)
                    <br /><br />
                    > <b>Rendering xhtml_tag_br</b>: <?php br::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_font</b>: <?php font::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_font (without defining content)</b>: <?php font::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_font_simpleText (without defining alignment)</b>: <?php simpleText::render(TEST_CONTENT); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_font_simpleText (center alignment defined)</b>: <?php simpleText::render(TEST_CONTENT, 'center'); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_font_simpleText (with invalid alignment 'test')</b>: <?php simpleText::render(TEST_CONTENT, 'test'); ?>
                    <br /><br />
                    > <b>Rencering xhtml_tag_font_simpleText (with custom face&size attributes)</b>: <?php simpleText::render(TEST_CONTENT, 'center', 5, 'lucida calligraphy'); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p (without defining content)</b>: <?php p::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p</b>: <?php p::render(TEST_CONTENT); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (without defining content and type)</b>: <?php uiMessage::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (without defining type)</b>: <?php uiMessage::render(TEST_CONTENT); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (notice)</b>: <?php uiMessage::render(TEST_CONTENT, 'notice'); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (warning)</b>: <?php uiMessage::render(TEST_CONTENT, 'warning'); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (error)</b>: <?php uiMessage::render(TEST_CONTENT, 'error'); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_p_uiMessage (with invalid type 'test')</b>: <?php uiMessage::render(TEST_CONTENT, 'test'); ?>
                    <br /><br />
                    > <b>Rendering page_element_navigation</b>: <?php navigation::create(); ?>
                    <br /><br />
                    > <b>Rendering page_element_navigation_naviBar</b>: <?php naviBar::create(); ?>
                    <br /><br />
                    > <b>Rendering ajax_source_element</b>: <?php element::render(); ?>
                    <br /><br />
                </td>
                <td width="666">
                    > <b>DEFINED COSTANTS</b>: <?php print_r(get_defined_constants(true)); ?>
                    <?php
                    foreach ($configuration['required_paths'] as $key => $values)
                    {
                        $constant_name = strtoupper($values['path']) . '_PATH';

                        if (!defined($constant_name))
                        {
                            uiMessage::render("Required constant '" . $constant_name . "' was not defined!", "warning");
                        }
                        else
                        {
                            echo "<br />";
                        }

                        if (!file_exists($values['path'] . "/"))
                        {
                            uiMessage::render("Required path '" . $values['path'] . "' (" . $values['abstract'] . ") not found!", 'error');
                        }
                    }
                    ?>
                    > <b>Rendering xhtml_tag_iframe (without defining file)</b>: <?php iframe::render(); ?>
                    <br /><br />
                    > <b>Rendering xhtml_tag_iframe</b>: <?php iframe::render('../info.php'); ?>
                    <br /><br />
                </td>
            </tr>
        </table>
    </body>
</html>