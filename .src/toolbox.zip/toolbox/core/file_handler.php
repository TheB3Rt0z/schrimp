<?php

abstract class file_handler implements file
{
    private $_access_modes = array
    (
        'read' => array
        (
            'r',
        ),

        'write' => array
        (
            'a',
            'w',
        ),

        'both' => array
        (
            'r+',
            'a+',
            'w+',
        ),
    );

    private $_filename = null;

    private $_mode = null;

    private $_handler = null;

    public function __construct($filename, $mode)
    {
        $this->_filename = $filename;

        $this->_mode = strtolower($mode);

        if (!$this->_validate_filename())
        {
            uiMessage::render("File name '" . $filename . "' couldn't be validated!", 'error');
        }
        elseif (!$this->_validate_mode())
        {
            uiMessage::render("File access mode '" . $mode . "' not allowed!", 'error');
        }
        elseif ($this->_filename)
        {
            $this->_handler = $this->_open_handler();
        }
    }

    private function _is_readable()
    {
        return (in_array($this->_mode, $this->_access_modes['read'])
            || in_array($this->_mode, $this->_access_modes['both']));
    }

    private function _is_writable()
    {
        return (in_array($this->_mode, $this->_access_modes['write'])
            || in_array($this->_mode, $this->_access_modes['both']));
    }

    private function _is_readable_and_writable()
    {
        return in_array($this->_mode, $this->_access_modes['both']);
    }

    private function _validate_filename()
    {
        return (($this->_is_readable() && file_exists($this->_filename))
            || $this->_is_writable()
            || $this->_is_readable_and_writable() && !substr_count($this->_mode, 'r'));
    }

    private function _validate_mode()
    {
        return ((ALLOW_AMBIVALENT_HANDLER_MODES && $this->_is_readable_and_writable())
            || ($this->_is_readable() || $this->_is_writable()));
    }

    private function _open_handler()
    {
        return fopen($this->_filename, $this->_mode);
    }

    function get_handler()
    {
        return $this->_handler;
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'get_handler',
        );

        return test_abstract_class(__CLASS__, $public_methods);
    }
}

?>