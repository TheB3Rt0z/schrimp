<?php

interface page
{
    public function create();
}

?>