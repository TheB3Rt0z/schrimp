<?php

class db_connection_mysql_mysqlQuery extends db_connection_mysql
{
    function execute($mysql_query)
    {
        parent::query($mysql_query);
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'execute',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>