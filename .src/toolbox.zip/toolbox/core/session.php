<?php

interface session
{
    public function start();
}

?>