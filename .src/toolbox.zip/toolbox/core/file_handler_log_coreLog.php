<?php

class file_handler_log_coreLog extends file_handler_log
{
    private static $_log_types = array
    (
        'notice' => 1,
        'warning' => 2,
        'error' => 3,
    );

    private function _calculate_log_level($type)
    {
        $log_level = 0;
        if (array_key_exists($type, self::$_log_types))
        {
            $log_level = self::$_log_types[$type];
        }

        return $log_level;
    }

    function read_to_string()
    {
        return parent::read(LOGS_PATH . 'core_' . gmdate('Y_m_d') . '.log');
    }

    function read_to_array()
    {
        return parent::read(LOGS_PATH . 'core_' . gmdate('Y_m_d') . '.log', true);
    }

    function write($content = '', $type = 'debug')
    {
        if (self::_calculate_log_level($type) >= VERBOSITY_CONTROL)
        {
            parent::write(LOGS_PATH . 'core_' . gmdate('Y_m_d') . '.log', $content, $type);
        }
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'read_to_string',
            'read_to_array',
            'write',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>