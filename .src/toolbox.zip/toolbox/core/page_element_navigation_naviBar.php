<?php

class page_element_navigation_naviBar extends page_element_navigation
{
    function create()
    {

    }

    public function auto_test()
    {
        $public_methods = array
        (
            'create',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>