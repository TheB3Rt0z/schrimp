<?php

class db_connection_object extends db_connection
{
    private $_class = '';

    private $_id = 0;

    private $_ukey = '';

    private $_metadata_created = false;

    private $_connection_backend = null;

    private $_query_backend = null;

    public $storage;

    public function __construct($id_ukey = false)
    {
        parent::__construct(DATABASE_TYPE);

        $this->_query_backend = DATABASE_TYPE . "Query";

        if ($id_ukey)
        {
            $this->storage = $this->get_storage($id_ukey);
        }
    }

    private function _calculate_ukey()
    {
        if ($this->_ukey
            && $this->_is_ukey($this->_ukey))
        {
            return $this->_ukey;
        }
        else
        {
            if (! $this->_class)
            {
                uiMessage('error');
            }

            if (! $this->_metadata_created)
            {
                uiMessage('error');
            }

            $md5_ukey = md5($this->_class . $this->_metadata_created . microtime());

            $this->_ukey = $md5_ukey;

            return $this->_ukey;
        }
    }

    private function _is_ukey($md5_string)
    {
        if (is_string($md5_string))
        {
            $md5_string = trim($md5_string);

            if (strlen($md5_string) == 32)
            {
                return true;
            }
        }
        else
        {
            // error not a string, wron passed value
        }

        return false;
    }

    private function _verify_identifier($id_ukey)
    {
        if (is_int($id_ukey))
        {
            return "ID = " . $id_ukey;
        }
        elseif ($this->_is_ukey($id_ukey))
        {
            return "UKEY = '" . $id_ukey . "'";
        }
        else
        {
            return false;
        }
    }

    function connect()
    {
        return $self->_connection_backend->connect();
    }

    function query($query_string = '')
    {
        return $self->_query_backend->execute($query_string);
    }

    function create($class_name)
    {
        $self = new self();

        $self->_class = $class_name;

        $self->_ukey = $self->_calculate_ukey();

        $create_query = "INSERT INTO " . $self->_class . "
                         SET UKEY = '" . $self->_ukey;

        if ($self->query($create_query))
        {
            $this->_id = $self->_query_backend->get_last_insert_id();
        }
    }

    function update($new_values = array())
    {
        $update_query = "UPDATE " . $this->_class . "
                         SET
                         WHERE ID " . $this->_id;

        return $this->query($update_query);
    }

    function delete()
    {
        $delete_query = "DELETE FROM " . $this->_class . "
                         WHERE ID = " . $this->_id;

        return $this->query($delete_query);
    }

    function get_storage($id_ukey = false)
    {

    }

    public function auto_test()
    {
        $public_methods = array
        (
            'create',
            'update',
            'delete',
        );

        $private_methods = array
        (
            '_calculate_ukey',
            '_is_ukey',
            '_verify_identifier',
        );

        return test_class(__CLASS__, $public_methods, $private_methods);
    }
}

?>