<?php

interface file
{
    public function read();

    public function write();
}

?>