<?php

interface system
{
    public function execute();
}

?>