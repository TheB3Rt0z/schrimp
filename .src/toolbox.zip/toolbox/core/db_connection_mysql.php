<?php

class db_connection_mysql extends db_connection
{
    public function __construct()
    {
        parent::__construct('mysql');
    }

    function connect()
    {
        $self = new self;

        if ($self->get_connection())
        {
            coreLog::write("connected to database", strtoupper(__CLASS__));
        }
        else
        {
            uiMessage::render(strtoupper(__CLASS__) . " database connection not possible!", 'error');
        }

        return $self;
    }

    function query($mysql_query = '')
    {
        $self = self::connect();

        $self->_query = trim($mysql_query);

        if ($mysql_result = mysql_query($self->_query))
        {
            return $mysql_result;
        }
        else
        {
            uiMessage::render(strtoupper(__CLASS__) . " mysql query returned false: '" . mysql_error() . "'!", 'error');
        }
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'connect',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>