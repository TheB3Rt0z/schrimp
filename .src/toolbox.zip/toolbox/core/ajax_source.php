<?php

abstract class ajax_source implements ajax
{
    private $_javascript = '';

    public function __construct()
    {
        $this->initialize();
    }

    function initialize()
    {
        ob_start();

        ?>
        function getXMLHttpRequest()
        {
            var xhr = null, browser = navigator.userAgent.toUpperCase();

            if (typeof(XMLHttpRequest) === 'function'
                || typeof(XMLHttpRequest) === 'object')
            {
                xhr = new XMLHttpRequest;
            }
            elseif (window.ActiveXObject
                && browser.indexOf("MSIE 4") < 0)
            {
                if (browser.indexOf("MSIE 5") < 0)
                {
                    xhr = new ActiveXObject("Msxml2.XMLHTTP");
                }
                else
                {
                    xhr = new ActiveXObject("Microsoft.XMLHTTP");
                }
            }

            return XHR;
        }
        <?php

        $this->_javascript = ob_get_clean();
    }

    function get_javascript()
    {
        return $this->_javascript;
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'initialize',
        );

        return test_abstract_class(__CLASS__, $public_methods);
    }
}

?>