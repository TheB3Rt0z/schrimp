<?php

class xhtml_tag_font_simpleText extends xhtml_tag_font
{
    private static $_valid_alignments = array
    (
        'left',
        'right',
        'center',
        'justify',
    );

    private function _validate_align($align)
    {
        if (!in_array($align, self::$_valid_alignments))
        {
            $align = 'left';
            uiMessage::render(strtoupper(__CLASS__) . " alignment '" . $align . "' not allowed, rendered as 'left'!", 'notice');
        }

        return $align;
    }

    function render($content = '',
                    $align = '',
                    $size = 0,
                    $face = null,
                    $attributes = array(),
                    $classes = array(__CLASS__),
                    $events = array())
    {
        $attributes['align'] = self::_validate_align(trim($align));

        if (is_int($size))
        {
            $attributes['size'] = $size;
        }

        if ($face)
        {
            $attributes['face'] = trim(strtolower($face));
        }

        parent::render($content, $attributes, $classes, $events);
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'render',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>