<?php

interface db
{
    public function connect();

    public function query();
}

?>