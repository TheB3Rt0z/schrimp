<?php

abstract class page_element implements page
{
    function get_something() {}

    public function auto_test()
    {
        $public_methods = array
        (
            'get_something',
        );
        
        return test_abstract_class(__CLASS__, $public_methods);
    }
}

?>