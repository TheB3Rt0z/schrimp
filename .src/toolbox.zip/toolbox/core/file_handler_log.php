<?php

class file_handler_log extends file_handler
{
    public function __construct($filename = null)
    {
        parent::__construct($filename, 'a');
    }

    function read($filename = '', $to_array = false)
    {
        $self = new self($filename);

        if ($to_array
            && $contents = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
        {
            return $contents;
        }

        if ($contents = file_get_contents($filename))
        {
            return $contents;
        }

        uiMessage::render("File '" . $self->_filename . "' opened in mode '" . $self->_mode . "' not readable!", 'error');
    }

    function write($filename = '', $content = '', $type = false)
    {
        $self = new self($filename);

        $content = gmdate('H:i:s') . (($type) ? " [" . strtoupper($type) . "]" : '') . " " . $content . "\r\n";

        if (!fwrite($self->get_handler(), $content))
        {
            uiMessage::render("File '" . $self->_filename . "' opened in mode '" . $self->_mode . "' not writable!", 'error');
        }

        fclose($self->get_handler());
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'read',
            'write',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>