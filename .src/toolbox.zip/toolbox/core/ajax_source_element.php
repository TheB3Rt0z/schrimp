<?php

class ajax_source_element extends ajax_source
{
    public function __construct()
    {
        parent::__construct();
    }

    function render()
    {
        $self = new self;

        $self->initialize();

        javaScript::render($self->get_javascript());

        coreLog::write("rendered class object", strtoupper(__CLASS__));
    }

    function request()
    {
        ?>
        if (ajax getXMLHttpRequest())
        {
            // esempio di richiesta pagina con metodo get
            ajax.open("get", "cartella/ajax.html?leggi=Dante", true);

            // esempio di richiesta pagina con metodo post
            ajax.open("post", "cartella/ajax.html", true);

            // spazio per le eventuali istruzioni
        }
        <?php
    }

    function update()
    {
        ?>
        if (ajax getXMLHttpRequest())
        {
            // spazio per le eventuali istruzioni
        }
        <?php
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'render',
            'request',
            'update',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>