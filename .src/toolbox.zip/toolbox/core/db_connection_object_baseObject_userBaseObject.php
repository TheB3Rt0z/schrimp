<?php

class db_connection_object_baseObject_userBaseObject extends db_connection_object_baseObject
{
    public $username = '';

    public $password = '';

    public $name = '';

    public $surname = '';

    function is_logged()
    {

    }

    public function auto_test()
    {
        $public_methods = array
        (
            'is_logged',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>