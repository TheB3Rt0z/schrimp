<?php

abstract class db_connection implements db
{
    private $_supported_types = array
    (
        'mysql',
    );

    private $_type = null;

    private $_connection = null;

    private $_query = '';

    public function __construct($type)
    {
        $this->_type = strtolower(trim($type));

        if (!$this->_is_supported())
        {
            uiMessage::render(strtoupper(__CLASS__) . " db '" . $this->_type . "' not supported!", 'error');
        }

        switch ($this->_type)
        {
            case 'mysql' :
            {
                if (!$this->_connection = mysql_connect(DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD))
                {
                    $error_message = strtoupper(__CLASS__) . " could not connect to host (ip address: '" . DATABASE_HOST . "') "
                                   . "with provided username and password ('" . DATABASE_USERNAME . "'/'" . DATABASE_PASSWORD . "')!";
                    uiMessage::render($error_message, 'error');
                }

                if (!mysql_select_db(DATABASE_NAME))
                {
                    if (DATABASE_AUTOCREATE)
                    {
                        uiMessage::render(strtoupper(__CLASS__) . " trying to auto-create '" . DATABASE_NAME . "'..", 'warning');

                        if (mysql_query("CREATE DATABASE " . DATABASE_NAME))
                        {
                            uiMessage::render(strtoupper(__CLASS__) . " db '" . DATABASE_NAME . "' succesfully created!", 'notice');
                        }
                        else
                        {
                            uiMessage::render(strtoupper(__CLASS__) . " auto-creation of db '" . DATABASE_NAME . "' failed!", 'error');
                        }
                    }
                    else
                    {
                        uiMessage::render(strtoupper(__CLASS__) . " db '" . DATABASE_NAME . "' not found!", 'error');
                    }
                }

                break;
            }
        }
    }

    private function _is_supported()
    {
        return in_array($this->_type, $this->_supported_types);
    }

    function get_connection()
    {
        return $this->_connection;
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'get_connection',
        );

        return test_abstract_class(__CLASS__, $public_methods);
    }
}

?>