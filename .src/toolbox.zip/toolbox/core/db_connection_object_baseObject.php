<?php

class db_connection_object_baseObject extends db_connection_object
{
    function get_id()
    {
        return $this->_id;
    }

    function get_ukey()
    {
        return $this->_ukey;
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'get_id',
            'get_ukey',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>