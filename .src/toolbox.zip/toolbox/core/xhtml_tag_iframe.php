<?php

class xhtml_tag_iframe extends xhtml_tag
{
    public function __construct($data = array())
    {
        parent::__construct($data, 'iframe');
    }

    private function _validate_src($src)
    {
        return (file_exists($src) && is_readable($src));
    }

    function render($src = '', $attributes = array(), $classes = array(__CLASS__), $events = array())
    {
        if (!self::_validate_src(trim($src)))
        {
            uiMessage::render(strtoupper(__CLASS__) . " src '" . $src . "' not valid, aborting", 'error');
        }

        $data['attributes'] = $attributes;
        $data['attributes']['src'] = $src;

        $data['classes'] = $classes;

        $data['events'] = $events;

        $self = new self($data);

        echo $self->get_html();

        coreLog::write("rendered class object", strtoupper($data['classes'][0]));
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'render',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>