<?php

class db_connection_object_dataRetriever extends db_connection_object
{
    function run()
    {

    }

    public function auto_test()
    {
        $public_methods = array
        (
            'run',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>