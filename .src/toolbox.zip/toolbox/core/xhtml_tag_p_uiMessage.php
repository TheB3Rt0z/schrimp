<?php

class xhtml_tag_p_uiMessage extends xhtml_tag_p
{
    private static $_type_symbols = array
    (
        'debug' =>'',
        'notice' => "(i)",
        'warning' => "(?)",
        'error' => "(!)",
    );

    private function _validate_type($type)
    {
        return array_key_exists($type, self::$_type_symbols);
    }

    private function _determine_class_from_type($type)
    {
        switch ($type)
        {
            case 'debug' :
            {
                $class = 'debug';
                break;
            }

            case 'notice' :
            {
                $class = 'green';
                break;
            }

            case 'warning' :
            {
                $class = 'orange';
                break;
            }

            case 'error' :
            {
                $class = 'red';
                break;
            }
        }

        return $class;
    }

    function render($content = '', $type = 'debug', $attributes = array(), $classes = array(__CLASS__), $events = array())
    {
        if (!SHOW_UI_MESSAGES)
        {
            return false;
        }

        if (!self::_validate_type($type))
        {
            uiMessage::render(strtoupper(__CLASS__) . " type '" . $type . "' not allowed, aborting", 'error');
        }

        $classes[] = self::_determine_class_from_type($type);

        parent::render(self::$_type_symbols[$type] . " " . $content, $attributes, $classes, $events);

        coreLog::write($content, $type);

        if (($type == 'error')
            && !AUTO_TEST)
        {
            exit;
        }
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'render',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>