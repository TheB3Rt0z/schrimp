<?php

class xhtml_tag_p extends xhtml_tag
{
    public function __construct($data = array('content' => ''))
    {
        parent::__construct($data, 'p');
    }

    function render($content = '', $attributes = array(), $classes = array(__CLASS__), $events = array())
    {
        $data['content'] = $content;

        $data['attributes'] = $attributes;

        $data['classes'] = $classes;

        $data['events'] = $events;

        $self = new self($data);

        echo $self->get_html();

        coreLog::write("rendered class object", strtoupper($data['classes'][0]));
    }

    public function auto_test()
    {
        $public_methods = array
        (
            'render',
        );

        return test_class(__CLASS__, $public_methods);
    }
}

?>