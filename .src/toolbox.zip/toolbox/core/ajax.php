<?php

interface ajax
{
    public function render();

    public function request();

    public function update();
}

?>