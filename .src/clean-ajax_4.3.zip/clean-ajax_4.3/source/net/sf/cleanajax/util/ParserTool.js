/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides some parsing algorithms.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");

/**
* <p>Multi-purpose parser constructor.</p>
*/
function ParserTool() {
};

/**
* <p>Encode the fields present on a form to URL.</p>
* @param form
*		<code>HTMLForm</code> to encode.
* @return
*		<code>String</code> with form URL encoded data.
*/
ParserTool.formToUrl = function(form) {
  var url = "";
  try {
    for(var i = 0; i < form.elements.length; ++i) {  
	  if(form.elements[i].type != null)
        switch(form.elements[i].type.toLowerCase()) {	  
	   	  case "button":
		  case "reset": break;	
	      case "radio":		
	      case "checkbox":
	        if(form.elements[i].checked)
		     url += form.elements[i].name + "=" + escape(form.elements[i].value) + "&";
 	        break;	
	      case "select-one":
            url += form.elements[i].name + "=" + escape(form.elements[i].options[form.elements[i].selectedIndex].value) + "&";
            break;
	      case "select-multiple":
	        for(var v = 0; v < form.elements[i].options.length; ++v) {
              if(form.elements[i].options[v].selected)
		        url += form.elements[i].name + "=" + escape(form.elements[i].options[v].value) + "&";
		    }
            break;		
	      default:
	        url += form.elements[i].name + "=" + escape(form.elements[i].value) + "&";
	        break;	  
        }
    }
    url = url.substr(0, (url.length - 1));
    return url;
  } 
  catch(e) {
	  Engine.reportException(null, e);	  
  }  
};

/**
* <p>Encode a JavaScript var to a HTML representation used 
* to display registers on trace console.</p>
* @param value
*		The var value.
* @param id
*		HTML id attribute used to identify the object.
* @param is_text
*		<code>Boolean</code> flag that indicates if the value must be render as plain text.
* @return
*		<code>String</code> with the trace register in HTML.
*/
ParserTool.jsToTraceRegister = function(value, id, is_text) {
  try {	
    txt = (id != null) ? "<div class='hide' id='" + id + "'>" : "<div>";      
    if(is_text)
      txt += "<textarea cols='40' rows='8' wrap='off'>" + value.replace(/\t/g, "") + "</textarea>"; 
	else
    if(typeof value == "object")  
      for(var i in value) {     
        txt += "<p><b>" + i + "</b> = " + value[i] + "</p>"; 	
	  }
    else
      txt += "<p>" + value + "</p>"; 
    return txt += "</div>" ;
  } 
  catch(e) {
	  Engine.reportException(null, e);	  
  }  
};