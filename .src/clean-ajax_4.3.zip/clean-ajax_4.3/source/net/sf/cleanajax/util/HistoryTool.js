/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides HistoryTool features for AJAX requests.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.dom.DomIterator");

/**
* <p>AJAX HistoryTool constructor.</p>
*/
function HistoryTool() {
};

/** <p>Name of the iframe used to cache data and to control HistoryTool navigation.</p> */
HistoryTool.IFRAME = "clean_ajax_HistoryTool_iframe";

/** <p>Id of the last event on the HistoryTool.</p> */
HistoryTool.last = null;

/** <p>Hash table used to store HistoryTool events.</p> */
HistoryTool.hashTable = {};

HistoryTool.hackOpera = false;

/**
* <p>Save an event on the HistoryTool and also save consumer content on cache.</p>
* @param doc
*		<code>Document</code> used to find the consumer element.
* @param consumer
*		Consumer element id.
*/
HistoryTool.save = function(doc, consumer) {	 
  try {
    HistoryTool.last = (new Date()).getTime();
    HistoryTool.hashTable[HistoryTool.last] = { doc: doc, consumer: consumer };		  
    var iterator = new DomIterator(doc);	           	
    var cache = window.cleanHistoryFrame.contentWindow.document;	 	  	    	    
    if(window.cleanHistoryFrame != null) {  
      // Form cache	      	
   	  if(clean_environment.userAgent.isSafari || clean_environment.userAgent.isChrome) {
        cache.forms[0].elements[0].value = "key=" + HistoryTool.last +"&value=" + iterator.getValue(consumer);
        cache.forms[0].action = "#?last=" + HistoryTool.last; 
        cache.forms[0].submit();
      }
      // IFrame cache
      else {      	
        var html = "<html><head></head><body>";	      	
 	    html += "<div id='key'>" + HistoryTool.last + "</div>";		
	    html += "<div id='value'>" + iterator.getValue(consumer) + "</div>";  
	    // Hack for Opera.
	    if(clean_environment.userAgent.isOpera)
	      html += "<img src=\"javascript:location.href='javascript:parent.opera.iframeOnLoadHack();';\">";      		  	    	
	    html += "</body></html>";	    
        cache.open();
	    cache.write(html);
        cache.close();       
      }       	      
    }
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }  
};

/**
* <p>Load a field stored on the cache.</p>
* @param field
*		Field name on iframe.
* @return
*		Field value or null.
*/
HistoryTool.load = function(field) {
  var value = HistoryTool.last;
  try {	
    if(window.cleanHistoryFrame != null) {	    	
      var cache = window.cleanHistoryFrame.contentWindow.document;
      if(clean_environment.userAgent.isSafari || clean_environment.userAgent.isChrome) {
      	  // Load cache data from form
      	  var data = cache.forms[0].elements[0].value;
      	  if(data != null){
      	  	data = data.split("&");
      	    for(var cnt = 0; cnt < data.length; ++cnt){
      	    	if(data[cnt].indexOf(field) != -1){      	    		
      	    	   value = data[cnt].split("=")[1];
      	    	   break;
      	    	}
      	    }
      	  }
      } else{
      	  // Load cache data from iframe      	
         var el = cache.getElementById(field);
         if(el != null)
           value = el.innerHTML;                   	
      }
    }
	return value;
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }    
};

/**
* <p>Monitor back and forward navigation and restore content from the cache.</p>
*/
HistoryTool.change = function() {
  try {
    var key = HistoryTool.load("key"); 
    if((key != HistoryTool.last) && (HistoryTool.last != null)) {	  
	  HistoryTool.last = key;
      var iterator = new DomIterator(HistoryTool.hashTable[HistoryTool.last].doc);
      iterator.applyValue(HistoryTool.hashTable[HistoryTool.last].consumer, HistoryTool.load("value"), true);	
    }
  } 
  catch(e) { /* Ignore the exception */ }   
};

/**
* <p> Install AJAX HistoryTool on browser.</p>
*/
HistoryTool.install = function() {
  var iframe = document.createElement("iframe"); 
  iframe.name = HistoryTool.IFRAME;	
  iframe.id = HistoryTool.IFRAME;      
  iframe.style.display = "none"; 		
  document.body.appendChild(iframe);
  window.cleanHistoryFrame = iframe;	
  // IE	
  if(clean_environment.userAgent.isMsie) {
	window.cleanHistoryFrame.onreadystatechange = function() {
	  if (window.cleanHistoryFrame.readyState == "complete") {
	    HistoryTool.change(); 
	  }
    };
  }
  // Mozilla 
  else if(clean_environment.userAgent.isMozilla) {  	
    window.cleanHistoryFrame.onload = function() {
      HistoryTool.change();
    };
  }  
  // Opera 	
  else if(clean_environment.userAgent.isOpera) {  	
  	// Opera does not fire iframe onload when user hit back and forward buttons, so we hack.
  	window.opera.iframeOnLoadHack = function() {
  	  HistoryTool.change();
  	};
  }
  // Safari and Chrome
   else if(clean_environment.userAgent.isSafari || clean_environment.userAgent.isChrome) {   	   	
     window.cleanHistoryFrame.src = clean_environment.cleanPath + "resources/form-cache.html";
   }
};	