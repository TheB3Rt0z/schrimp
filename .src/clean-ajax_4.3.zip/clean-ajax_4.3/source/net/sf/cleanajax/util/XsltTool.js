/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a cross-browser XSLT processor.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");

/**
* <p>XSLT processor tool constructor.</p>
*/
function XsltTool() {
};

/** 
* <p>Transforms a XML document based on a XSLT document.</p>
* @param origin
*		<code>XMLDocument</code> to be transformed.
* @param style
*		<code>XMLDocument</code> that is a valid XSLT document used to perform the transformation.
* @return
*		<code>String</code> that represents the result of the transformation.
*/
XsltTool.transform = function(origin, style) {
  try {
    if(typeof XSLTProcessor != "undefined") {			
	  var proc = new XSLTProcessor();
	  proc.importStylesheet(style);
	  return (new XMLSerializer()).serializeToString(proc.transformToDocument(origin));
    }
	else 
	if(window.ActiveXObject != null) {	
	  var proc = Engine.buildActiveX(Engine.ACTIVEX_DOM);
	  proc.async = "false";	  
	  proc.load(origin);	
	  return proc.transformNode(style);	
    }
	// Use external library if browser doesn't support XSLT.    
	else{
	 importLibrary(clean_environment.libraries.ajaxslt);
     return xsltProcess(origin, style);
	}	
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }	
};