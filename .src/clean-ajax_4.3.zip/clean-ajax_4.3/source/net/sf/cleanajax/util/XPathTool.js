/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a cross-browser XPath evaluator.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");

/**
* <p>Generic XPath tool constructor. </p>
*/
function XPathTool() {
};

/**
* <p>Perform xpath evaluation</p>
* @param expression	
*   XPath expression to evaluate.
* @param doc
*   Document to be evaluated. 
* @return
* 	A list with all elements retrieved by the expression.
*/
XPathTool.evaluate = function(expression, doc) { 
  try {
    var result = new Array();
	if(typeof doc.evaluate != "undefined") {
	  var xpathResult = doc.evaluate(expression, doc, null, XPathResult.ANY_TYPE, null);
	  var node = xpathResult.iterateNext();    
	  while(node) {
	    result.push(node);
	    node = xpathResult.iterateNext();
	  }
	}
	// Use external library if browser doesn't support XPath.	
	else { 
	  if(typeof xpathDomEval == "undefined")
	    importLibrary(clean_environment.libraries.ajaxslt);
	  var xpathResult = xpathDomEval(expression, doc);
	  result = xpathResult.value;	  
	}      	  
  	return result;
  }
  catch(e) { 
    Engine.reportException(null, e); 
  }		
};