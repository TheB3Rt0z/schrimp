/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides features to trace message data and 
* to be aware about messages' life cycle.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.dom.DomIterator");
importClass("net.sf.cleanajax.util.ParserTool");

/**
* <p>Trace console constructor. </p>
*/
function Console() {	
}

/** <p>Messages trace counter.</p> */
Console.counter = 1;

/** <p><code>Window</code> used to open the console.</p> */
Console.window = null;

/** <p>Remote procedure call event id.</p> */
Console.RPC_DATA = "rpc_data"; 

/** <p>Request event id.</p> */
Console.REQUEST = "request"; 

/** <p>Response event id.</p> */
Console.RESPONSE = "response"; 

/** <p>Exception event id.</p> */
Console.EXCEPTION = "exception";

/**
* <p>Start the console. It adds a link to the current document 
* that can be used to open the console window.</p>
*/
Console.start = function() {
  try {
    var opener = document.createElement("div"); 
    opener.align = "right";	
    opener.style.width = "auto";
    opener.style.right = "5px"; 
    opener.style.top = "0px"; 	
    opener.innerHTML = "<a style='color:#000000; text-decoration: none; background:#FFFFFF; border:1px solid #000000;' href='javascript:Console.open()'>Clean Console</a>";
	document.body.insertBefore(opener, document.body.firstChild);
  } 
  catch(e) {
	  Engine.reportException(null, e);	  
  }   
};

/**
* <p>Open the console window.</p>
*/
Console.open = function() {
  try {	
    if(!Console.isOpen())
	  Console.window = window.open(clean_environment.cleanPath + "resources/console.html", "console", "height=350,width=450,scrollbars");
	Console.window.focus();
  } 
  catch(e) {
	  Engine.reportException(null, e);	  
  }   
};

/**
* <p>Check if the console window is open.</p>
* @return
*		<code>Boolean</code> flag that indicates if the console window is open.
*/
Console.isOpen = function() {
  if(Console.window == null)
    return false;
  else
    return (!(Console.window.closed) && (Console.window.document != null));
};

/**
* <p>Append trace register on the message console.</p>
* @param value
*		Trace data to display.
* @param trace_event
*		The trace event (data, request, response, exception).
*/
Console.trace = function(value, trace_event) {
  try {	
    if(Console.isOpen()) {	
      var stack = ParserTool.jsToTraceRegister(Console.counter, null, false);
      var data = ParserTool.jsToTraceRegister(value, Console.counter, (trace_event == Console.RPC_DATA));
      var title = "<a href='javascript:expand(" + Console.counter + ")'>" + trace_event.toUpperCase() + "</a>";	  
      // Increase message counter.
      ++Console.counter;	
      var iterator = new DomIterator(Console.window.document);      
      var table = iterator.getElementById("trace_table");
      var row = table.insertRow(-1);	
      row.className = trace_event;
      var cell_1 = row.insertCell(-1);
      var cell_2 = row.insertCell(-1);	
      cell_1.vAlign = "top";
      cell_2.vAlign = "top";
      cell_1.innerHTML = stack;		
      cell_2.innerHTML = title + data;	
    }
  } 
  catch(e) {
	  Engine.reportException(null, e);	  
  }    
};