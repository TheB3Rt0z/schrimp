/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a simplified implementation for XML Schema Qualified Name.
* @author Carlos Eduardo Goncalves
*/

/**
* <p>XML Schema Qualified Name: <a href="http://www.w3.org/TR/xmlschema-2/#QName">
* XML Schema Part2: Datatypes specification</a></p>
* @param namespace_uri
*		Define the name space to be set on the QName.
* @param local_part
*		Define the local part to be set on the QName.
* @param prefix
*		Define the prefix the to be set on the QName.
*/
function QName(namespace_uri, local_part, prefix) {
  /** <p>Name space of the QName.</p> */	
  QName.prototype.namespaceURI = namespace_uri;
  /** <p>Local part of the QName.</p> */	  
  QName.prototype.localPart = local_part;
  /** <p>Prefix of the QName.</p> */	  
  QName.prototype.prefix = prefix;
};

/**
* <p>Transform a QName to a <code>String</code> representation.</p>
* @return
* 		<code>String</code> with the full qualified name representation.
*/
QName.prototype.toString = function() {
  return this.prefix + ":" + this.localPart + " xmlns:" + this.prefix + "='" + this.namespaceURI + "'";
};

/**
* <p>Return the qualified name value.</p>
* @return
* 		<code>String</code> with the qualified name value (perfix:localPart).
*/
QName.prototype.getValue = function() {
  return this.prefix + ":" + this.localPart;
};