/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Extensions to JavaScript core <code>Date</code> Class
* @author Carlos Eduardo Goncalves
*/

/**
* <p>Convert a GMT date to ISO8601.</p>
* @return
*		<code>String</code> with an ISO8601 date.
*/
Date.prototype.toIso8601 = function() {
  var year = this.getYear();
  if(year < 1900) 
    year += 1900;   
  var month = this.getMonth() + 1;
  if(month < 10) 
    month = "0" + month;     
  var day = this.getDate();
  if(day < 10) 
    day = "0" + day;     
  var time = this.toTimeString().substr(0,8);
  return year + month + day + "T" + time;
};

/**
* <p>Convert ISO8601 date to GMT.</p>
* @param value
*		ISO8601 date.
* @return
*		GMT date.
*/
Date.fromIso8601 = function(value) {
  var year = value.substr(0,4); 
  var month = value.substr(4,2);
  var day = value.substr(6,2); 
  var hour = value.substr(9,2); 
  var minute = value.substr(12,2); 
  var sec = value.substr(15,2);  
  return new Date(year, month - 1, day, hour, minute, sec, 0);
};

/**
* <p>Convert date to JSON notation.</p>
* @return
*		JSON date.
*/
Date.toJson = function(){
  function fmt(n) {
    return n < 10 ? "0" + n : n;
  }
  return this.getUTCFullYear() + "-" + fmt(this.getMonth() + 1) + "-" + fmt(this.getUTCDate()) + "T" + fmt(this.getUTCHours()) + ":" + fmt(this.getUTCMinutes()) + ":" + fmt(this.getUTCSeconds())+ "Z";	
}