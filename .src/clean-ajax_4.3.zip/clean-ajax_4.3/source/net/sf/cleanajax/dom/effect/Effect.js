/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides basic effect features for DOM elements.
* @author Carlos Eduardo Goncalves
*/

/**
* <p>Effect constructor.</p>
* @param params
* 		<code>EffectParams</code> used to define effect behavior.
*/
function Effect(params) {
  /** <p>Hold effect params.</p> */	  
  Effect.prototype.params = {};
  this.params.steps = params.steps ? (params.steps > 0 && params.steps <= 30) ? params.steps : 30 : 25; 
  this.params.delay = params.delay ? (params.delay > 0 && params.delay <= 100) ? params.delay : 100 : 50;
  this.params.style = params.style ? (Effect.STYLES.toString().indexOf(params.style.toString().toUpperCase()) != -1) ? params.style : "FADE" : "FADE";     
  /** <p>Define the style of transition use by the effect.</p> */  
  Effect.prototype.transition = null; 
  switch(this.params.style.toUpperCase()){
   case "FADE":
     this.transition = Effect.transitions.fade;
     break;
   default:
     this.transition = Effect.transitions.drop;  	 
  }     
  /** <p>Define the current step of the effect.</p> */	
  Effect.prototype.currentStep = 0;    
  /** <p>Flag used to identify if the effect will show or hide the target.</p> */  
  Effect.prototype.show = false;      
  /** <p>Hold properties of effect's target.</p> */  
  Effect.prototype.element = null;
  /** <p>Hold event interval.</p> */  
  Effect.prototype.interval = 0; 
  /** <p>Event handler used to apply content to the element before display it again (for internal use).</p> */
  Effect.prototype.onBeforeFinish = null;    
  /** <p>Event handler used to start complementary effect (for internal use).</p> */
  Effect.prototype.onFinish = null;
};

/** <p>Supported styles.</p> */  
Effect.STYLES = ["FADE", "HDROP", "VDROP", "DDROP"];

/**
* <p>Control effect execution from first to last step.</p>
*/
Effect.prototype.loop = function() {
  var _this = this;	
  var _continue = this.advance(this.currentStep);
  // Check if advance was successful and it can keep going.
  if(_continue === false){
  	clearInterval(this.interval);
    return;  	
  } 
  // Increase step.      	
  this.currentStep++;
  // Check if is was the last step.   
  if(this.currentStep >= this.params.steps){
  	clearInterval(this.interval);
  	// Call onBeforeFinish
    if(this.onBeforeFinish != null)
      setTimeout(function(){_this.onBeforeFinish();}, this.params.delay);
  	// Call onFinish           	          	
  	if(this.onFinish != null){
  	  Effect.running = false; 
  	  this.onFinish();
  	}  		  	    
  }
};

/**
* <p>Start the effect.</p>
* @param element
* 		DOM element to apply effect.
*/
Effect.prototype.start = function(element) {	
  if(!Effect.running){
   	var _this = this;  	
    Effect.running = true;  	  
    this.element = element;	 	    
    this.interval = setInterval(function(){_this.loop();}, this.params.delay);
    // If show is true we are running a complementary effect.
   	if(this.show){
   	  this.onFinish = function(){
    	Effect.running = false;
   	  };    		
   	}
   	else{
      this.onFinish = function(){  
      	// Create a complementary effect that reverts the animation.		
        var complement = new Effect(_this.params);
        complement.show = true;
    	complement.start(_this.element);
       };   			
    }  	
  }
};

/**
* <p>Apply a single increment on element's style.</p>
*/
Effect.prototype.advance = function(step) {
  var rate = this.transition((step + 1) / this.params.steps); 
  switch(this.params.style.toUpperCase()){
  	case "FADE":     	
      var opacity = this.show ? 0 + (1 - 0) * rate : 1 + (0 - 1) * rate;	
      this.element.style.opacity = "" + opacity;
      this.element.style.filter = "alpha(opacity=" + opacity * 100 + ");zoom: 1";
      break;
    case "VDROP":  
      if(step == 0 && !this.show){
        Effect.store.height = this.element.clientHeight;
        this.element.style.overflow = "hidden";              	
      } 	
      else if(step == 0 && this.show){  	
		Effect.store.height = this.element.scrollHeight;      	              			
      }		      
      var height = this.show ? 0 + Math.round(Effect.store.height * rate) : Effect.store.height - Math.round(Effect.store.height * rate);
      this.element.style.height = height + "px";
  	  break;    
  	case "HDROP":    
      if(step == 0  && !this.show){
      	Effect.store.width = this.element.clientWidth;
      	this.element.style.overflow = "hidden";
      }       	 	        
      var width = this.show ? 0 + Math.round(Effect.store.width * rate) : Effect.store.width - Math.round(Effect.store.width * rate);
      this.element.style.width = width + "px";
  	  break; 	
  	case "DDROP":    
      if(step == 0  && !this.show){
      	Effect.store.height = this.element.clientHeight;
      	Effect.store.width = this.element.clientWidth;
		this.element.style.overflow = "hidden";      	
      } 	 
      else if(step == 0 && this.show){  	
		Effect.store.height = this.element.scrollHeight;    
      }	      	        
      var height = this.show ? 0 + Math.round(Effect.store.height * rate) : Effect.store.height - Math.round(Effect.store.height * rate);      
      var width = this.show ? 0 + Math.round(Effect.store.width * rate) : Effect.store.width - Math.round(Effect.store.width * rate);
      this.element.style.height = height + "px";     	 	
      this.element.style.width = width + "px";
  	  break;   	   
  } 	 		
};

/** <p>Flag used to indicate that there is already an effect running.</p> */
Effect.running = false;

/** <p>Transitions used to randomize the style transformation.</p> */
Effect.transitions = {};

/** <p>Temporary store object.</p> */  
Effect.store = {};

/**
* <p>Algorithm used on fade transformations.</p>
* @param value
*		<code>Number</code> that represents the value to be applied to element's opacity.
*/
Effect.transitions.fade = function(value) {
    return (Math.sin( Math.PI * (value - 0.5)) + 1) / 2;
};

/**
* <p>Algorithm used on drop down transformations.</p>
* @param value
*		<code>Number</code> that represents the value to be applied to element's height. 
*/
Effect.transitions.drop = function(value) {
    return Math.sin( Math.PI * (value - 1) / 2) + 1;
};
