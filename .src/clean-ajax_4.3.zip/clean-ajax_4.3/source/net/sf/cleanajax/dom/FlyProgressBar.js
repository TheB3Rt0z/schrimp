/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class that creates a progress bar able 
* to follow page scroll.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");

/**
* <p>FlyProgressBar constuctor. </p>
* @param doc
*		<code>Document</code> used to add the progress bar.
* @param content
*		HTML content to display (usually img tag). 
*/
function FlyProgressBar(doc, content) {
  try {	
    /** <p><code>Document</code> used to add the progress bar.</p> */  
    FlyProgressBar.prototype.doc = doc;
    /** <p>Element that is used to display a progress bar.</p> */
    FlyProgressBar.prototype.bar = this.doc.createElement("div"); 
    this.bar.innerHTML = content;  
    this.bar.align = "left";  	
    this.bar.style.width = "auto";	
    this.bar.style.left = "5px"; 
    this.bar.style.top = "0px"; 
    this.bar.style.margin = "0px"; 
	this.bar.style.padding = "0px"; 	
    this.bar.style.position = "absolute";
    this.bar.style.display = "none";  
    this.doc.body.insertBefore(this.bar, this.doc.body.firstChild); 		
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }  
};

/**
* <p>Hook function called to update the progress bar.</p>
* @param show
*		<code>Boolean</code> flag that indicates if the bar must be showed or not.
*/
FlyProgressBar.prototype.update = function(show) {
  try {
     var top = 0;
     if(window.pageYOffset != null) 
	   top = window.pageYOffset;
     else 
	 if((this.doc.documentElement != null) && (this.doc.documentElement.scrollTop != null)) 
	   top = this.doc.documentElement.scrollTop;
     else 
	 if((this.doc.body != null) && (this.doc.body.scrollTop != null))
	   top = this.doc.body.scrollTop;  
	this.bar.style.top = top + "px";
    this.bar.style.display = (show == true) ? "block" : "none";		
  } 
  catch(e) { /* Ignore the exception  */ }    
};

/**
* <p>Gracefully destroy the progress bar.</p>
*/
FlyProgressBar.prototype.free = function() {
  try {	
     this.doc.body.removeChild(this.bar);
  } 
  catch(e) { /* Ignore the exception  */ }    
};