/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class that uses an element embedded in a
* document to indicate progress status.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");

/**
* <p>EmbeddedProgressBar constructor. </p>
* @param doc
*		<code>Document</code> used to find the progress bar.
* @param element_id
*		Element id attribute (usually the element is a img tag).
*/
function EmbeddedProgressBar(doc, element_id) {
  try {	
    /** <p><code>Document</code> used to find the progress bar.</p> */
    EmbeddedProgressBar.prototype.doc = doc;
    var iterator = new DomIterator(doc);
    /** <p>Element that is used to display a progress bar.</p> */
    EmbeddedProgressBar.prototype.bar = iterator.getElementById(element_id);
  } 
  catch(e) { 
    Engine.reportException(null, e);
  }  
};

/**
* <p>Hook function called to update the progress bar.</p>
* @param show
*		<code>Boolean</code> flag that indicates if the bar must be showed or not.
*/
EmbeddedProgressBar.prototype.update = function(show) {
  try {	
    if(this.bar != null)
      this.bar.style.display = (show == true) ? "inline" : "none";		
  } 
  catch(e) { /* Ignore the exception  */ }    
};

/**
* <p>Gracefully destroy the progress bar.</p>
*/
EmbeddedProgressBar.prototype.free = function() {
};