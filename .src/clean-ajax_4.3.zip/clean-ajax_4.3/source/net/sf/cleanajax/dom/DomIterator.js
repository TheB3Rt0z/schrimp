/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class based on Iterator design pattern used to provide 
* abstraction from DOM elements.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.util.XPathTool");

/**
* <p>Document object model iterator constructor.</p>
* @param doc
*		<code>Document</code> used to iterate in.
*/
function DomIterator(doc) {
  /** <p><code>Document</code> used by the iterator.</p> */	
  DomIterator.prototype.doc = doc;
};

/**
* <p>Search for an element on a document and change its value.</p>
* @param id
*		DOM element id attribute value.
* @param value
*		Value to be applied on element.
* @param replace_old
*		Flag used to determine if the value must be concatenated to the 
*		old value or if the value must replace the old value.
*/
DomIterator.prototype.applyValue = function(id, value, replace_old) {
  try {
    var el = this.getElementById(id);
	if(el == null) 
	  return;
    var iframes = this.getElementsByTagName("iframe");
    for(var i = 0; i <= iframes.length; ++i) {
	  if(iframes[i] != null)
  	    if(iframes[i].id == el.id) {
  	      el.contentWindow.document.body.innerHTML = (replace_old) ? value : el.contentWindow.document.body.innerHTML + value;
	      return;
	    }
    }
	if(el.value != null) {
       el.value = (replace_old) ? value : el.value + value;	  
	   return;
    }
	if(el.innerHTML != null) {
       el.innerHTML = (replace_old) ? value : el.innerHTML + value;	  
	   return;
    }
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }
};

/**
* <p>Search for an element on a document and return its value.</p>
* @param id
*		DOM element id attribute value.
* @return
*		Element value or null.
*/
DomIterator.prototype.getValue = function(id) {
  try {
    var el = this.getElementById(id);
	if(el == null) 
	  return null;
    var iframes = this.getElementsByTagName("iframe");
    for(var i = 0; i <= iframes.length; ++i) {
	  if(iframes[i] != null)
  	    if(iframes[i].id == el.id)
	      return el.contentWindow.document.body.innerHTML;
    }
	if(el.value != null)
	   return el.value;
	if(el.innerHTML != null)
	   return el.innerHTML;
  } 
  catch(e) { 
    Engine.reportException(null, e);
  }
};

/**
* <p>Search a form in the document, using the form id attribute as search key.</p>
* @param form_id
*		<code>HTMLForm</code> id attribute value.
* @return
*		<code>HTMLForm</code> instance recovered.
*/
DomIterator.prototype.getFormById = function(form_id) {	
  var form = null;
  var forms = this.getElementsByTagName("form"); 
  for(var i = 0; i <= forms.length; ++i) {
    if(forms[i] != null) {
      if(forms[i].id == form_id) {
	    form = forms[i];
	    break;
      }
    }
  }
  return form;
};

/**
* <p>Search a form in the document, using the form name attribute as search key.</p>
* @param form_name
*		<code>HTMLForm</code> name attribute value.
* @return
*		<code>HTMLForm</code> instance recovered.
*/
DomIterator.prototype.getFormByName = function(form_name) {	
  var form = null;	
  var forms = this.getElementsByTagName("form"); 
  for(var i = 0; i <= forms.length; ++i) {
    if(forms[i] != null) {
      if(forms[i].name == form_name) {
	    form = forms[i];
	    break;
      }
    }
  }	
  return form;
};

/**
* <p>Retrieve a set of elements from DOM using its tag name.</p>
* @param tag
* 		Element tag name.
* @return
*      <code>Array</code> with all elements retrieved.
*/
DomIterator.prototype.getElementsByTagName = function(tag) {
  // Google AJAXSLT much slower than getElementsByTagName (IE / Safari).
  if((clean_environment.userAgent.isMsie) || (clean_environment.userAgent.isSafari))
    return this.doc.getElementsByTagName(tag);
  else {
    var xpath = "//" + tag;	
    var result = XPathTool.evaluate(xpath, this.doc);
    return result;
  }    
};

/**
* <p>Retrieve an element from DOM using its id attribute.</p>
* @param id
* 		Element id attribute value.
* @return
*     	Element retrieved or null.
*/
DomIterator.prototype.getElementById = function(id) {
  // Google AJAXSLT much slower than getElementById (IE / Safari).
  if((clean_environment.userAgent.isMsie) || (clean_environment.userAgent.isSafari))
    return this.doc.getElementById(id);    
  else {
    var xpath = "//*[@id='" + id + "']";	
    var result = XPathTool.evaluate(xpath, this.doc);   
    return result.pop();
  }    
};

/**
* <p>Retrieve a set of elements from DOM using theirs class attribute.</p>
* @param clazz
* 		Element class attribute value.
* @return
*      <code>Array</code> with all elements retrieved.
*/
DomIterator.prototype.getElementsByClass = function(clazz) {
  var xpath = "//*[@class='" + clazz + "']";	
  var result = XPathTool.evaluate(xpath, this.doc);       
};