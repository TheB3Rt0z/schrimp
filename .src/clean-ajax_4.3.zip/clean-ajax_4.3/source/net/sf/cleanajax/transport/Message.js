/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class based on Value Object design pattern
* used to avoid changes on method's signatures
* @author Carlos Eduardo Goncalves
*/

/** 
* <p>AJAX message constructor.</p>
*/
function Message() {
  /** <p>Message unique id.</p> */
  Message.prototype.id = null;	
  /** <p>HTTP method used to send the request.</p> */  
  Message.prototype.method = "";
  /** <p>URL to request.</p> */  
  Message.prototype.address = null;
  /** <p>URL to a XSLT file to apply on response.</p> */  
  Message.prototype.xslt = null;
  /** <p>Value to apply on request.</p> */  
  Message.prototype.value = null;
  /** <p><code>Document</code> used to find the message consumer element.</p> */  
  Message.prototype.doc = document;  
  /** <p>Message consumer element id.</p> */  
  Message.prototype.consumer = null;	
  /** <p>Flag that defines if consumer value will be refreshed.</p> */  
  Message.prototype.refresh = true;
  /** <p>Flag that defines if response will be cached.</p> */    
  Message.prototype.cache = true;
  /** <p>Flag that defines if the message will display any progress bar.</p> */  
  Message.prototype.silent = false;
  /** <p><code>Object</code> used to apply effect when content is attached to message's consumer.</p> 
   *  <p>It can has 3 attributes:</p> 
   *   <li>steps: define the total steps of the effect (default = 25, range= 0-30).<li> 
   *   <li>delay: define the time delay for each step (default = 50, range= 0-100).<li>
   *   <li>style: define effect style (default = fade, range= fade, hdrop, vdrop, ddrop).<li> 
   * */  
  Message.prototype.effect = null;  
  /** 
  * <p>Private progress bar used by the message.</p> 
  * @see EmbeddedProgressBar
  * @see FlyProgressBar
  */  
  Message.prototype.progressBar = null;
  /** <p>Event handler called at response progress. If null a built-in handler will be applied dinamically.</p> */  
  Message.prototype.onChange = null;
  /** <p>Event handler called when a exception occurs. Receives as parameter the exception object.</p> */  
  Message.prototype.onError = null;  
  /** <p>Event handler called after response. Receives as parameter a XMLHttpRequest object with request data.</p> */  
  Message.prototype.onComplete = null;  
};