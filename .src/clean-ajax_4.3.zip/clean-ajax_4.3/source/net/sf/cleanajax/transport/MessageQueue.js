/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a simple queue to add messages in.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.transport.MessageWrapper");

/** 
* <p>AJAX message queue constructor.</p>
*/
function MessageQueue() {
};

/** <p>Map that holds all active messages.</p> */
MessageQueue.messages = {};		

/** 
* <p>Add a new AJAX message to the queue.</p>
* @param msg
*		<code>Message</code> value object to be added.	
* @return
*		<code>MessageWrapper</code> instance stored on the queue.
*/
MessageQueue.add = function(msg) { 
  try {
    var wrapper = new MessageWrapper();
    wrapper.wrap(msg);
    MessageQueue.messages[wrapper.id] = wrapper;	 
    return wrapper;
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }
};

/** 
* <p>Remove an AJAX message from the queue.</p>
* @param msg_id
*		<code>Message<code> unique identifier on the message queue. 		
*/
MessageQueue.remove = function(msg_id) {
  try {	
      delete MessageQueue.messages[msg_id];
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }	
};

/** 
* <p>Method used to safe access messages map and recover
* a message wrapper.</p>
* @param msg_id
*		<code>Message</code> unique identifier on the message queue.	
* @return 
*		<code>MessageWrapper</code> instance or <code>null</code>.
*/
MessageQueue.getMessage = function(msg_id) {
  try {	
    if(MessageQueue.messages[msg_id] != "undefined")
      return MessageQueue.messages[msg_id];
    else
      return null;
  } 
  catch(e) { 
    Engine.reportException(null, e);
  }		
};

/** 
* <p>Method used to clear message queue.</p>
*/
MessageQueue.clear = function() {	
  try {
    for(var wrapper in MessageQueue.messages) {	  
      if(MessageQueue.messages[wrapper] != "undefined")	  
	    if(MessageQueue.messages[wrapper].request.readyState == 4) 
	      delete MessageQueue.messages[wrapper];	  
	}
  } 
  catch(e) { 
    Engine.reportException(null, e);
  }		
};

/** 
* <p>Check if the queue has any active message.</p>
* <p>Silent messages are ignored.</p>
* @return 
*		<code>Boolean</code> flag that indicates if the are active messages.
*/
MessageQueue.hasActiveMessage = function() {	
  try {
    var active = false;
    for(var wrapper in MessageQueue.messages) {
      if(MessageQueue.messages[wrapper] != "undefined")	
        if((MessageQueue.messages[wrapper].request.readyState < 4) && (MessageQueue.messages[wrapper].silent == false)) {
	      active = true;
	      break;
	    }	  
    }
    return active;
  } 
  catch(e) { 
    Engine.reportException(null, e);
  }	  
};

/**
* 
*/
MessageQueue.getUniqueId = function() {
  var timestamp = (new Date()).getTime();
  return timestamp;
};