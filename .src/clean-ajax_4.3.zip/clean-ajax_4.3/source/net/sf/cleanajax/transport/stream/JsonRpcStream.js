/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class used to read/write JSONRPC web services data streams.
* This implementation is focused on web service client requirements,
* it means that it is only able to write requests and read responses.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.data.Date");
importClass("net.sf.cleanajax.log.Console");

/**
* <p>Json stream constructor.</p>
*/
function JsonRpcStream(){
};

/** <p>JSON request.</p> */
JsonRpcStream.REQUEST = "{\"version\":\"1.1\", \"method\":\"${METHOD}\", \"params\":[${DATA}]}";

/** <p>Unicode char map used to format strings. It can arise at runtime.</p> */
JsonRpcStream.char_map = {'\b':'\\b','\t':'\\t','\n':'\\n','\f':'\\f','\r':'\\r','"':'\\"','\\':'\\\\'};

/**
* <p>Write a JSON-RPC request.</p>
* @param method
*		<code>RemoteMethod</code> value object.
* @return
*		<code>String</code> with JSON object representation.
*/
JsonRpcStream.prototype.write = function(method) {
  try {		
    if(!Engine.assertType(method, RemoteMethod))
	  return null;
    var json_params = "";	  
    for(var i = 0; i < method.params.length; i++)
      json_params += this.serialize(method.params[i]);      	      
	var json_call = JsonRpcStream.REQUEST.replace("${METHOD}", method.getName());			
    json_call = json_call.replace("${DATA}", json_params);    
	Console.trace(json_call, Console.RPC_DATA);
	return json_call;
  } 
  catch(e) { 
    Engine.reportException(null, e); 
  }     	   
};

/**
* <p>Read a JSON-RPC response.</p>
* @param json
*		<code>String</code> with JSON object representation.
* @return
*		JavaScript object.
*/
JsonRpcStream.prototype.read = function(json) {
  var validator = /'^("(\\\\.|[^"\\\\\\n\\r])*?"|[,:{}\\[\\]0-9.\\-+Eaeflnr-u \\n\\r\\t])+?$'/;
  return validator.test(json) ? this.unserialize(json) : undefined;
};

/**
* <p>Encode a JavaScript object to JSON.</p>
* @param data
*		JavaScript object to be encoded.
* @return
*		<code>String</code> with JSON object representation.
*/
JsonRpcStream.prototype.serialize = function(data) {
  try {
	var json = "null";	
	if(!(data === null)){		
	  var type = typeof data;
	  switch(type.toLowerCase()) { 	  	  
	    case "number":
	      json = data.isFinite() ? new String(data) : "null";
	      break;
	    case "boolean":
	      json = new String(data);
	      break;
		case "string":
		  json = '"' + data.replace(/["\\\x00-\x1f\x7f-\x9f]/g, JsonRpcStream.escapeUnicode) + '"';
		  break;           
		case "object": 	  	
	      if(data.constructor == Number)
		    json = data.isFinite() ? data.valueOf() : "null";
		  else
		  if(data.constructor == Boolean)
		    json = data.valueOf();
		  else		
	      if(data.constructor == String)
   		  	json = '"' + data.replace(/["\\\x00-\x1f\x7f-\x9f]/g, JsonRpcStream.escapeUnicode) + '"';
		  else  
		  if(obj.constructor == Date){
		    json = data.toJson();  	
		  }	      
		  else
		  if(data.constructor == Array){
		    for(var i = 0, temp_arr = []; i < data.length; i++) {
          		temp_arr.push(this.serialize(data[i])); 
	    	}
		    json = "[" + temp_arr.join(",") + "]";
		  }
		  else{
		  	var temp_arr = [];
		  	for(var i in data) {
              temp_arr.push(i + ":" + this.serialize(data[i]));
		  	}
			json = "{" + temp_arr.join(",") + "}";		  	
		  }	
		  break;
	  }	
	}
	return json;
  }
  catch(e) { 
    Engine.reportException(null, e); 
  } 	
};

/**
* <p>Decode a JSON string to JavaScript.</p>
* @param json
*		<code>String</code> with JSON object representation.
* @return
*		JavaScript object. 
*/
JsonRpcStream.prototype.unserialize = function(json) {
  return eval("(" + json + ")");
};

/**
* <p>Replace unicode characters by an appropriate JSON representation.</p>
* <p>This method is able registers new chars not present in JsonRpcStream char map.</p>
* @param json
*		<code>String</code> without formatation.
* @return
*		<code>String</code> formatted. 
*/
JsonRpcStream.prototype.escapeUnicode = function(chr) {
  if(!JsonRpcStream.char_map[chr]){
    var a = chr.charCodeAt();
    JsonRpcStream.char_map[chr] = "\\u00" + Math.floor(a / 16).toString(16) + (a % 16).toString(16);
  }
  return JsonRpcStream.char_map[chr];  	
};