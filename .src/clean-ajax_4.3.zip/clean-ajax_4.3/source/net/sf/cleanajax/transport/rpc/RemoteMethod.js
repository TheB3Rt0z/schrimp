/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
* Provides a class that represents a remote method.
* @author Carlos Eduardo Goncalves
*/

importClass("net.sf.cleanajax.core.Engine");
importClass("net.sf.cleanajax.data.QName");

/** 
* <p>Remote method constructor.</p>
*/
function RemoteMethod() {
  /** 
  * <p>Method name. Can be a <code>String</code> or a <code>QName</code>.</p> 
  * @see QName
  */	
  RemoteMethod.prototype.name = null;	
  /** <p>Method parameters.</p> */	  
  RemoteMethod.prototype.params = new Array();
  /** <p>Method protocol.</p> */	  
  RemoteMethod.prototype.protocol = "SOAP";
  /** <p>Envent handler called to process the method result. Receives as parameter the parsed result object.</p> */	  
  RemoteMethod.prototype.onResult = null;
  /** <p>Envent handler called if a fault occurs on remote method. Receives as parameter the parsed fault object.</p> */	   
  RemoteMethod.prototype.onError = null;
};

/** <p>Supported protocols.</p> */
RemoteMethod.PROTOCOLS = ["SOAP", "XMLRPC", "JSONRPC"];

/**
* <p>Add a parameter to method parameters.</p>
* @param data
*		New parameter to include.		
*/
RemoteMethod.prototype.addParam = function(data) {
  this.params.push(data);	
};

/**
* <p>Clear method parameters.</p>
*/
RemoteMethod.prototype.clearParams = function() {
  this.params.splice(0, this.params.length);
};

/**
* <p>Recover the method name from a simple <code>String</code> 
* or a <code>QName</code>.</p>
* @return
*		A <code>String</code> with the method name.
* @see QName
*/
RemoteMethod.prototype.getName = function() {
  if(Engine.assertType(this.name, QName))
    return this.name.getValue();
  else
    return this.name;
};