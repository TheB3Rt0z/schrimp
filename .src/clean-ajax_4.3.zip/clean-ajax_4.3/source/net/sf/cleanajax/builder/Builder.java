/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/
package net.sf.cleanajax.builder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Provides custom builder that merges all Clean AJAX scripts in a single
 * JavaScript file.
 * 
 * @author Carlos Eduardo Goncalves
 */
public class Builder {

	
	/**
	 * Script files list. 
	 */
	private List<String> scriptList;

	/**
	 * Builder root directory. 
	 */
	private String rootPath;
	
	private static final String JAVASCRIPT_OPERATORS_PATTERN = "\\+_\\+\\+_\\-_\\-\\-_\\*_\\/_%_&&_\\|\\|_!_&_\\^_\\|_~_<<_>>_>>>_=_\\+=_\\-=_\\*=_\\/=_%=_&=_\\^=_\\|=_<<=_>>=_>>>=_==_!=_===_!==_>_>=_<_<=_,_\\?_:"; 

	/**
	 * Default constructor 
	 */
	public Builder(){
		scriptList = new ArrayList<String>();
		rootPath = "P:\\JavaScript\\Clean AJAX\\"; //System.getProperty("root_dir");		
	}
	
	
	public static void main(String[] args) {
		System.out.println("Parsing Files...");
		System.out.println();
		Builder builder = new Builder();
		builder.collectAllFiles(null);
		builder.buildAllInOneFile();	
		System.out.println("Moving Files...");
		System.out.println();		
	}

	
	/**
	 * Searches for JavaScript files in a specified directory.
	 * 
	 * @param path
	 * 		The directory path. 
	 */
	private void collectAllFiles(String path){		
		File rootFile = path == null ? new File(this.rootPath + "source" + File.separator) : new File(path);		
		File[] listed = rootFile.listFiles();
		for(File f : listed){
			if(f.isDirectory())
				collectAllFiles(f.getAbsolutePath());
			else{
				if(f.getName().matches(".*\\.js$")){
					scriptList.add(f.getAbsolutePath());
				}
			}
		}
	}
	
	
	/**
	 * Builds the all in one script. 
	 */
	private void buildAllInOneFile(){
		PrintWriter pw = null;
		try{
			File out = new File(this.rootPath + "deploy");
			out.mkdirs();
			pw = new PrintWriter(new FileWriter(new File(out, "clean-ajax-all.js")));
		}catch(IOException ioe){
			ioe.printStackTrace();		
		}
		pw.print(getCopyRight());
		int scriptCounter = 0;
		// Read each script collected		
		for(String script : scriptList){
			try{
				BufferedReader br = new BufferedReader(new FileReader(script));
				String line;
				while((line = br.readLine()) != null){					
					// ignore lines with importClass calls (on-demand JavaScript not used on single file deploy)
					if(Pattern.matches(".*importClass.*", line)){
						if(!Pattern.matches(".*function importClass.*", line))
							continue;
					}								
					// remove blank spaces from line
					line = line.trim();					
					// ignore empty lines 
					if(!(line.length() == 0 || line.startsWith("*") || line.startsWith("/"))){						
						// remove comments from line
						Pattern pattern = Pattern.compile("(.*[^\"])(\\/\\*\\*.*\\*\\/)(.*)");
						Matcher mtc = pattern.matcher(line);
						if(mtc.matches())
							line = mtc.group(1) + mtc.group(3);						
						// remove spaces between ( ), { } and  ) { 
						pattern = Pattern.compile("(.*[\\(|\\)|\\{])(\\s*)([\\)|\\{|\\}].*)");
						mtc = pattern.matcher(line);
						if(mtc.matches())						
							line = mtc.group(1) + mtc.group(3);							
						// remove spaces before and after operators																
						String[] operators = JAVASCRIPT_OPERATORS_PATTERN.split("_");
						for(String operator : operators){
							pattern = Pattern.compile("(\\s*)(" + operator + "{1})(\\s*)");
							mtc = pattern.matcher(line);
							while(mtc.find()){
								line = mtc.replaceAll(operator);
							}
						}						
						// write line to file
						pw.print(line.endsWith("else") ? line + " " : line);
					}	
				}	
				br.close();				
			}catch(IOException ioe){
				ioe.printStackTrace();
			}finally{
				++scriptCounter;
				// generate a new line for the next file (one file per line)				
				if(scriptCounter < scriptList.size()) 
					pw.println();
			}
		}
		pw.flush();
		pw.close();
	}
	
	private String getCopyRight() {
		StringBuilder sb = new StringBuilder();
		sb.append("/*\r\n");
		sb.append("*    Clean AJAX Engine v4.3\r\n");
		sb.append("*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)\r\n");
		sb.append("*\r\n");
		sb.append("*    Available via GNU General Public License (http://www.gnu.org/copyleft/gpl.html)\r\n");
		sb.append("*/\r\n");
		return sb.toString();
	}
	
}
