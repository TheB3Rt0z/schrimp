/*
*    Clean AJAX Engine v4.3
*    Copyright (C) 2005-2008 Carlos Eduardo Goncalves (cadu.goncalves@gmail.com)
*
*    This program is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

/** Define clean_environment object */
var clean_environment = {};

/** Version */
clean_environment.version = "4.3"; 

/** User agent */
clean_environment.userAgent = {}; 

/** Define debug mode (true or false) */
clean_environment.debug = false; 

/** Define the hash algorithm used on safe requests (md5 or sha1) */
clean_environment.hashAlgorithm = "md5";

/** Clean real path (Assigned dynamically) */
clean_environment.cleanPath = "";

/** Scripts loaded (Assigned dynamically)*/
clean_environment.scripts = {};

/** Classes loaded (Assigned dynamically)*/
clean_environment.classes = {};

/** Libraries loaded */
clean_environment.libraries = {};

// Google AJAXSLT
clean_environment.libraries.ajaxslt = ["ajaxslt.util", "ajaxslt.xmltoken", "ajaxslt.dom", "ajaxslt.xpath", "ajaxslt.xslt"];
// PajHome
clean_environment.libraries.pajhome = ["pajhome.md5", "pajhome.sha1"];
// Open Ajax Hub
clean_environment.libraries.openAjax = ["openajax.OpenAjax"];

/**
* Get script's real path.
*/
function getPath () {
  var path = "";
  var scripts = document.getElementsByTagName("script");
  for(var i = 0; i < scripts.length; i++ ) {	  
    var src = scripts[i].getAttribute("src");
	if(src) {
	  var loader = src.match(/^(.*?)\/?clean-ajax-[boot.js|all.js]/);
	  if(loader) {
	    var root = loader[0];
		path = root.substring(0, root.lastIndexOf("/") + 1);
		break;
	  }
    }
  }
  return path;
}

/**
* Import a script to the current page if it hasn't been imported yet.
*/
function importScript(file) {
  if(clean_environment.scripts[file] == undefined) {
    clean_environment.scripts[file] = file;   	
    if(clean_environment.userAgent.isSafari)
	   document.writeln("<script type='text/javascript' src='" + file + "'></script>");	   
    else {
      var head = document.getElementsByTagName("head")[0];
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = file;
      head.appendChild(script);
    }    
    return true;   
  } 
  return false;
}

/**
* Import all scripts in a library.
*/
function importLibrary(library) {	
  for(var f in library) {	  
    var file = library[f].replace(/\./g, "/") + ".js";
	importScript(clean_environment.cleanPath + "lib/" + file);
  }
}

/**
* Import a class script.
*/
function importClass(clazz) {
  var file = clazz.replace(/\./g, "/") + ".js";
  if(importScript(clean_environment.cleanPath + file)){
  	var clazzName = clazz.substring(clazz.lastIndexOf(".") + 1);
  	clean_environment.classes[clazzName] = clazzName;
  }  	
}

/**
* Sniffs the user's browser. 
*/
function sniffBrowser(){
  var agent = navigator.userAgent.toLowerCase();
  clean_environment.userAgent.isMsie = (agent.indexOf("msie") != -1);
  clean_environment.userAgent.isOpera = (agent.indexOf("opera") != -1);  
  clean_environment.userAgent.isChrome = (agent.indexOf("chrome") != -1);  
  clean_environment.userAgent.isSafari = (agent.indexOf("safari") != -1) && !clean_environment.userAgent.isChrome;  
  clean_environment.userAgent.isMozilla = (agent.indexOf("mozilla") != -1) && !(clean_environment.userAgent.isChrome | clean_environment.userAgent.isSafari | clean_environment.userAgent.isOpera);  
}	

/**
* Prepare start up at page load.  
*/
function prepareStart(){
  if(typeof window.addEventListener != "undefined")
    window.addEventListener("load", main, false);
  else 
  if(typeof document.addEventListener != "undefined")
    document.addEventListener("load", main, false);
  else 
  if(typeof window.attachEvent != "undefined")
	window.attachEvent("onload", main);
  else {
    if(typeof window.onload == "function") {
      var current = onload;
	  window.onload = function() {
	    current();
	    main();
	  };
    }
    else
      window.onload = main;
  }  	
}	

/**
* Clean main code 
*/
function main() {		
  if(typeof OpenAjax != "undefined") {	
    OpenAjax.hub.registerLibrary("clean-ajax", "http://clean-ajax.sourceforge.net", "4.2", {}); 
  }    
  HistoryTool.install();  
  Engine.start(clean_environment.debug, createEngineProgressBar());     
}

/**
* Extension point to define global progress bar shared by the application. 
*/
function createEngineProgressBar(){
  var img_path = clean_environment.cleanPath + "resources/loading.gif";
  var progress_bar = new FlyProgressBar(document, "<p><img src='" + img_path + "'/></p>");
  return progress_bar;		
}

/**
* Clean bootstrap code 
*/
function bootstrap() {
  clean_environment.cleanPath = getPath();  
  importLibrary(clean_environment.libraries.openAjax);  
  importLibrary(clean_environment.libraries.openAjax);
  importLibrary(clean_environment.libraries.pajhome);  
  if((typeof XSLTProcessor == "undefined") && (window.ActiveXObject == null))
    importLibrary(clean_environment.libraries.ajaxslt); 
  importClass("net.sf.cleanajax.core.Clean");       
  sniffBrowser();
  prepareStart();
}

bootstrap();