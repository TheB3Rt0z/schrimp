<?php // TODO: far sparire variabili con nome singolo tranne nei cicli

function read_configuration_file()
{
	define('MAIN_CONFIG',
           'mikro.cfg');

    $configuration_array = null;

	if (file_exists(MAIN_CONFIG))
	{
	    if (is_readable(MAIN_CONFIG))
	    {
	        eval("\$configuration_array = array(" . file_get_contents(MAIN_CONFIG) . ");");
	    }
	    else
	    {
	        trigger_error("Main configuration file not readable!", E_USER_WARNING);
	    }
	}
	else
	{
	    trigger_error("Main configuration file not found!", E_USER_ERROR);
	}

	return $configuration_array;
}

function create_simple_constant($value, $key, $custom)
{
    if (!is_array($value))
    {
        if (array_key_exists($key, $custom))
        {
            $value = $custom[$key];
        }

        $key = strtoupper($key);

        if (defined($key))
        {
        	trigger_error("System costant '" . $key . "' already defined!", E_USER_ERROR);
        }

        define($key, $value);
    }
}

function generate_system_constants($configuration_array)
{
	foreach ($configuration_array['required_paths'] as $key => $value)
	{
		$path = trim($value);

	    if (!empty($path))
	    {
	    	if (!file_exists($path))
	    	{
	    		trigger_error("Required file/directory '" . $path . "' is missing!", E_USER_ERROR);
	    	}

	    	define(strtoupper($path) . '_PATH',
	    	       './' . $path . '/');
	    }
	    else
	    {
	        trigger_error("Empty required_path specified!", E_USER_WARNING);
	    }
	}

	if ($_SERVER['HTTP_HOST'] == "localhost")
	{
	    $custom_configuration = $configuration_array['local_settings'];
	}
	else
	{
	    $custom_configuration = $configuration_array['online_settings'];
	}

	global $override_settings;

	$custom_configuration = array_merge_recursive($override_settings,
											      $custom_configuration);

	array_walk_recursive($configuration_array['main_framework'], 'create_simple_constant', $custom_configuration);
	array_walk_recursive($configuration_array['core_settings'], 'create_simple_constant', $custom_configuration);
	array_walk_recursive($configuration_array['application_settings'], 'create_simple_constant', $custom_configuration);

	return true;
}

function compare_string_length($a, $b)
{
    return strlen($a) > strlen($b);
}

function list_core_libraries()
{
	if (file_exists(CORE_PATH)
    	&& is_dir(CORE_PATH)
		&& $directory_handler = opendir(CORE_PATH))
    {
    	$files_list = array();

        while ($file_name = readdir($directory_handler))
        {
            if (is_file($file_path = CORE_PATH . $file_name))
            {
                $files_list[] = $file_name;
            }
        }

        usort($files_list, 'compare_string_length');

    	return $files_list;
    }
    else
    {
        trigger_error("Core directory isn't accessible or doesn't exists!", E_USER_ERROR);
    }
}

function load_core_tree($libraries_array)
{
	$core_classes = array();

	foreach ($libraries_array as $file_name)
    {
        include_once(CORE_PATH . $file_name);

        $path_length = strlen(CORE_PATH) - 3;
        $class_name = substr($file_name, 0, -$path_length);
        $name_array = explode('_', $file_name);
        $alias_name = substr(array_pop($name_array), 0, -$path_length);

        if ($name_array)
        {
        	if (!class_alias($class_name, $alias_name))
		    {
		        trigger_error("Unable to create alias '" . $alias_name . "' from class '" . $class_name . "'!", E_USER_WARNING);
		    }
	    }

		$core_classes[$alias_name] = $class_name;
    }

    return $core_classes;
}

function process_template($template_string)
{
	ob_start();
    	include(TEMPLATE_BASE . '.php');
    	$page_output = ob_get_contents();
    ob_end_clean();

    ob_start();
    	include($template_string);
    	$page_output = str_replace("__CONTENT__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_HEADER.php');
    	$page_output = str_replace("__HEADER__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_NAVIGATION.php');
    	$page_output = str_replace("__NAVIGATION__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_BREADCRUMB.php');
    	$page_output = str_replace("__BREADCRUMB__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_SIDEBAR.php');
    	$page_output = str_replace("__SIDEBAR__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_INFOBAR.php');
    	$page_output = str_replace("__INFOBAR__", ob_get_contents(), $page_output);
    	ob_clean();
    	include(TEMPLATE_BASE . '_FOOTER.php');
    	$page_output = str_replace("__FOOTER__", ob_get_contents(), $page_output);
    ob_end_clean();

    return $page_output;
}

function route_request($template_string)
{
	if ($_SERVER['QUERY_STRING'])
	{
	    $query_array = explode('&', str_replace(" ", '', $_SERVER['QUERY_STRING']));

	    foreach ($query_array as $value)
	    {
	    	if (count($value_components = explode('=', $value)) > 1)
	    	{
	    		$value = $value_components[0];
	    		$_POST[$value_components[0]] = $value_components[1];
	    	}

	    	$template_string .= '_' . $value;
	    }

	    $template_string .= '.php';

	    if (file_exists($template_string))
	    {
	        echo process_template($template_string);
	    }
	    else
	    {
	        include(TEMPLATE_BASE . '_404.php');
	    }
	}
	else
	{
	    include(TEMPLATE_BASE . '_HOME.php');
	}
}

if (generate_system_constants(read_configuration_file()))
{
	$mikro_version = date('y') - 12 . "."
	               . round((date('n') - 1) / 1.2) . "."
	               . sprintf("%02s",
	                         number_format(((date('j') / date('t')) * 100 - 1),
	                                       0,
                                           '',
                                           ''));
	define('FRAMEWORK_FINGERPRINT',
           "MiKRO version " . $mikro_version);

	$core_classes = load_core_tree(list_core_libraries());

	if (AUTO_TEST)
	{
		foreach ($core_classes as $class_alias => $class_name)
		{
			if (!tests::check_autotest_capability($class_name)
			    || !call_user_func($class_alias . '::auto_test'))
            {
                trigger_error("Auto-test failed for class '" . $class_name . "'!", E_USER_WARNING);
            }
		}
	}
//var_dump($_SERVER['HTTP_USER_AGENT'], $_SERVER['HTTP_ACCEPT'], $_SERVER['HTTP_X_WAP_PROFILE'], $_SERVER['HTTP_PROFILE'], $_SERVER['ALL_HTTP']);
	define('TEMPLATE_BASE', STYL_PATH . '/' . USED_TEMPLATE);

	route_request(TEMPLATE_BASE);
}

?>