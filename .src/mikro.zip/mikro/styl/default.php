<?php $html = new xhtml; $html->print_doctype(); ?>

<html>

	<head>
		<?php $html->load_stylesheets(USED_TEMPLATE); ?>
		<?php $html->load_favicon(USED_TEMPLATE); ?>
	</head>
	
	<body>
		<?php div::render("__HEADER__", array('id' => 'header')); ?>
		<?php div::render("__NAVIGATION__", array('id' => 'navigation')); ?>
		<?php div::render("__BREADCRUMB__", array('id' => 'breadcrumb')); ?>
		<?php div::render("__CONTENT__", array('id' => 'content')); ?>
		<?php div::render("__SIDEBAR__", array('id' => 'sidebar')); ?>
		<?php div::render("__INFOBAR__", array('id' => 'infobar')); ?>
		<?php div::render("__FOOTER__", array('id' => 'footer')); ?>
	</body>
	
</html>