<div id="container">
	<?php widgets::titledDiv("PROVA",
                             "lorem ipsum lorem ipsum lorem ipsum.. e altre stronzate per aumentare l'altezza di sto div!"); ?>
</div>

<?php elements::verticalSeparator(); ?>

<div id="interactive">
	<?php

	$lorem_ipsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ultricies viverra faucibus. Etiam a lectus non dui venenatis pretium id et enim. Curabitur rutrum fermentum sagittis. Quisque blandit, nisi a ultrices ullamcorper, metus purus blandit quam, malesuada laoreet mauris mi tempus odio. Sed eget aliquet felis. Duis vehicula arcu sed elit egestas auctor. Nullam congue tincidunt diam quis elementum. In hac habitasse platea dictumst. Vivamus blandit faucibus vestibulum. Donec pretium faucibus quam in volutpat.\nAliquam vitae felis eget sapien iaculis pretium placerat nec nulla. Nulla vestibulum urna ut sem consectetur at dictum lacus laoreet. Nullam ullamcorper aliquet massa, nec aliquam elit congue vel. Nam bibendum venenatis imperdiet. Ut mattis hendrerit neque, a lacinia nisl lobortis vitae. Pellentesque augue tellus, condimentum id auctor ac, consectetur ut velit. Nunc tristique viverra dolor, sit amet blandit lorem cursus at.\nDonec a eros in libero varius gravida id nec sem. Mauris pharetra ipsum at tortor porta scelerisque. Aliquam id felis nec nunc feugiat euismod. Nam eu augue nec lectus tristique sollicitudin. Vivamus nec ipsum ante. Donec placerat, ipsum sit amet scelerisque ullamcorper, turpis turpis volutpat velit, eget lacinia odio urna a orci. Etiam eu nulla consectetur erat sollicitudin faucibus. Morbi rhoncus erat quis lorem egestas in lobortis neque tristique. Curabitur tincidunt, sem a aliquam placerat, urna libero lobortis leo, sit amet consectetur nibh ante sed nisi. Duis porta libero vel odio ultrices ultricies elementum tellus dapibus. Quisque convallis elementum orci et congue.\nMorbi dapibus placerat mattis. Sed placerat pretium metus. Aliquam erat volutpat. Morbi vitae tellus nec dolor aliquet facilisis vel ut tortor. Ut bibendum leo ut urna varius sagittis. Nam fermentum felis ut lectus elementum imperdiet. Vestibulum ultricies, sem quis fringilla lacinia, enim lacus facilisis tellus, eu bibendum leo quam nec erat. Morbi dictum magna ac lectus rhoncus sit amet tincidunt justo interdum. Donec suscipit pretium imperdiet. Integer et turpis tellus, tincidunt tempus nunc. Etiam consectetur vestibulum mauris, et tristique libero auctor eu. Aenean a semper massa. Etiam ut sapien nec ipsum consequat semper eu non mauris.\nDonec interdum nisl sed est tincidunt porta. Nam varius iaculis mi, sed molestie tellus faucibus in. Praesent volutpat mauris tempus libero luctus semper. Maecenas semper, augue vitae iaculis luctus, orci enim egestas ligula, ac mollis magna quam id dolor. Vestibulum tristique quam quis turpis mattis hendrerit. Pellentesque vitae nulla ac nisi pharetra egestas. Nunc consequat erat sed ligula tristique consequat. Sed eu nulla felis.";

	widgets::windowDiv("PROVA",
	                   nl2br($lorem_ipsum));

	elements::horizontalSeparator();

	widgets::windowDiv("PROVA2",
	                   nl2br($lorem_ipsum),
	                   array(),
	                   false,
	                   true);

	?>
</div>