<?php $html = new xhtml; $html->print_doctype(); ?>

<html>

	<head>
		<?php
		$html->load_stylesheets(USED_TEMPLATE);
		$html->load_favicon(USED_TEMPLATE);
		$html->add_external_resource('jquery-min.js');
		?>
	</head>

	<body>
		<?php $html->semantic_div('content'); ?>
	</body>

</html>