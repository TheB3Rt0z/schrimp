<?php

global $override_settings;

$override_settings = array
(
  'used_template' => 'admin',
);

require_once('start.php');

?>