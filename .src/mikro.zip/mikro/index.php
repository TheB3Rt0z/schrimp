<?php

global $override_settings;

$override_settings = array();

require_once('start.php');

?>