<?php

class utility_tools extends utility
{
    public static function camelcase_underscored($checked_string)
	{
		if ($array_words = explode('_', strtolower($checked_string)))
		{
			$checked_string = $array_words[0];

			for ($i = 1; $i < count($array_words); $i++)
			{
				$checked_string .= ucfirst($array_words[$i]);
			}

			return $checked_string;
		}
		else
		{
			return strtolower(preg_replace('/(?<=\\w)(?=[A-Z])/',
	                                       "_$1",
	                                       $checked_string));
		}
	}

    static function auto_test($class_name = __CLASS__,
                              $parent_class = 'utility')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>