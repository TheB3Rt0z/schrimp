<?php

class wraps_page_elements extends wraps_page
{
    private static $_elements_counter = array
	(
		'horizontalSeparator' => 0,
		'verticalSeparator' => 0,
		//'simpleFont' => 0,
		//'simpleParagraph' => 0,
	);

	public static function horizontalSeparator($object_id = false)
	{
		$args_array = array
		(
			'content' => '&nbsp;',
			'attributes' => array
			(
				'class' => array
				(
					tools::camelcase_underscored(__FUNCTION__),
				)
			),
			'id' => parent::check_id($object_id,
		                             __FUNCTION__,
		                             self::$_elements_counter)
		);

		div::render($args_array);
	}

	public static function verticalSeparator($object_id = false)
	{
		$args_array = array
		(
			'content' => '&nbsp;',
			'attributes' => array
			(
				'class' => array
				(
					tools::camelcase_underscored(__FUNCTION__),
				)
			),
			'id' => parent::check_id($object_id,
		                             __FUNCTION__,
		                             self::$_elements_counter)
		);

		div::render($args_array);
	}

	public static function simpleFont()
	{

	}

    static function auto_test($class_name = __CLASS__,
                              $parent_class = 'wraps_page')
	{
		tests::public_method_counter_exists($class_name,
								            self::$_elements_counter);

		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>