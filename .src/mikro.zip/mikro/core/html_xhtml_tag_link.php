<?php

class html_xhtml_tag_link extends html_xhtml_tag
{
	public function __construct($link_attributes)
    {
    	parent::__construct('link',
    	                    $link_attributes,
                            '');
    }

	public static function render($args_array)
	{
		$link_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                         $args_array['attributes']);

		$self = new self($link_attributes);

    	$self->print_html();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml_tag')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>