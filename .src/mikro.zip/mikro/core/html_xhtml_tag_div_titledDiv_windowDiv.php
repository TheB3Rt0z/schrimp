<?php

// TODO: spostare javascript in un posto più consono (???)

class html_xhtml_tag_div_titledDiv_windowDiv extends html_xhtml_tag_div_titledDiv
{
	private $_show_toggle = null;

	private $_show_exit = null;

	private function add_toggle($div_id)
	{
		ob_start();
			?>
			$('#<?php echo $div_id; ?> > .content').toggle('fast');
	        $(this).data('toggled', !$(this).data('toggled'));
		    $(this).html('&nbsp;' + ($(this).data('toggled') ? '&nabla;' : '&Delta;') + '&nbsp;');
			<?php
			$javascript_code = ob_get_contents();
    	ob_end_clean();

		$toggle_attributes = array
		(
			'class' => array
			(
				'toggle',
			),
			'onclick' => $javascript_code,
		);

		return new div($toggle_attributes, "&nbsp;&Delta;&nbsp;");
	}

	private function add_exit($div_id)
	{
		ob_start();
			?>
			$('#<?php echo $div_id; ?>').toggle('fast');
			<?php
			$javascript_code = ob_get_contents();
    	ob_end_clean();

		$toggle_attributes = array
		(
			'class' => array
			(
				'exit',
			),
			'onclick' => $javascript_code,
		);

		return new div($toggle_attributes, "&nbsp;&times;&nbsp;");
	}

	public function __construct($div_attributes,
	                            $div_title,
	                            $div_content,
	                            $show_toggle = true,
	                            $show_exit = true)
	{
		$this->_show_exit = $show_exit;

		if ($this->_show_exit)
		{
			$exit_div = $this->add_exit($div_attributes['id']);
		}

		$this->_show_toggle = $show_toggle;

		if ($this->_show_toggle)
		{
			$toggle_div = $this->add_toggle($div_attributes['id']);
		}

		$composite_title = (isset($exit_div) ? $exit_div->get_html() : '')
		                 . (isset($toggle_div) ? $toggle_div->get_html() : '')
		                 . $div_title;

		parent::__construct($div_attributes,
		                    $composite_title,
		                    $div_content);
    }

	public static function render($args_array)
	{
		$div_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                        $args_array['attributes']);

		$self = new self($div_attributes,
		                 $args_array['title'],
    	                 $args_array['content'],
    	                 $args_array['toggle'],
    	                 $args_array['exit']);

    	$self->print_html();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml_tag_div_titledDiv')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>