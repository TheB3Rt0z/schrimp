<?php

class utility_tests extends utility
{
    public static function check_autotest_capability($class_name)
    {
    	$reflected_class = new ReflectionClass($class_name);

    	$auto_test_check = false;

		foreach ($reflected_class->getMethods(ReflectionMethod::IS_PUBLIC) as $key => $method)
	    {
	        if (($method->name == 'auto_test')
	            && $method->isStatic())
	        {
	            $auto_test_check = true;
	        }
	    }

	    if (!$auto_test_check)
	    {
	        // TODO: ui message invece del trigger qui sotto

	        //trigger_error("Static auto_test method not found in class '" . $reflection_class->name . "'!", E_USER_NOTICE);
	    }

	    return true;
    }

    public static function public_method_counter_exists($class_name,
                                                        $counters_array)
	{
		$reflected_class = new ReflectionClass($class_name);

		$public_methods = $reflected_class->getMethods(ReflectionMethod::IS_PUBLIC);

		foreach ($public_methods as $key => $object)
		{
			if ($object->name != 'auto_test'
				&& !array_key_exists($object->name,
				                     $counters_array))
			{
				var_dump($object->name); // TODO: message + logging
			}
		}
	}

	public static function common_class_tests($class_name,
	                                          $parent_name)
	{
		$reflected_class = new ReflectionClass($class_name);

		return (($reflected_class->name == $class_name)
			&& ((!$reflected_class->getParentClass() && !$parent_name)
				|| ($reflected_class->getParentClass()->name == $parent_name)));
	}

    static function auto_test($class_name = __CLASS__,
                              $parent_class = 'utility')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>