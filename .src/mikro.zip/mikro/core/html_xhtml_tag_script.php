<?php

class html_xhtml_tag_script extends html_xhtml_tag
{
	public function __construct($script_attributes,
								$content_code)
    {
    	parent::__construct('script',
    	                    $script_attributes,
    	                    $content_code);
    }

	public static function render($args_array)
	{
		$script_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                           $args_array['attributes']);

		$self = new self($script_attributes,
    	                 $args_array['content']);

    	$self->print_html();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml_tag')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>