<?php

class html_cehtml extends html
{
	public function print_doctype()
	{
		parent::set_doctype(CEHTML_DOCTYPE);

		parent::print_doctype();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>