<?php

class wraps
{
	protected static function check_id($object_id,
	                                   $method_name,
	                                   &$counters_array)
	{
		$counters_array[$method_name]++;

		if (!$object_id)
		{
			$object_id = $method_name . "_" . $counters_array[$method_name];
		}

		return $object_id;
	}

	static function auto_test($class_name = __CLASS__,
	                          $parent_class = false)
	{
		return tests::common_class_tests($class_name,
		                                 $parent_class);
	}
}

?>