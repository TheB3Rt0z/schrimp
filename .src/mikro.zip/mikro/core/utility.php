<?php

class utility
{
	static function auto_test($class_name = __CLASS__,
	                          $parent_class = false)
	{
		return tests::common_class_tests($class_name,
		                                 $parent_class);
	}
}

?>