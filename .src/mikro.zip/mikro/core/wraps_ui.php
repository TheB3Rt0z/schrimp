<?php

class wraps_ui extends wraps
{
	protected static function check_id($object_id,
	                                   $method_name,
	                                   &$counters_array)
	{
		return parent::check_id($object_id,
		                        $method_name,
		                        $counters_array);
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'wraps')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>