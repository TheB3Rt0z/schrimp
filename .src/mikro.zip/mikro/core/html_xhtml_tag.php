<?php

// realizzare tag rimanenti, solo se necessario, secondo lo schema..

class html_xhtml_tag extends html_xhtml
{
    private $_current_tag = null;

    private $_w3c_tags = array
    (
        'single' => array
        (
        	'br',
            'link',
        ),

        'container' => array
        (
            'font',
            'div',
            'script',
        ),

        'deprecated' => array
        (
            'font',
        ),
    );

    private $_tag_content = '';

    private $_tag_attributes = array();

    private $_tag_html = '';

	private function _is_single()
    {
        return in_array($this->_current_tag,
                        $this->_w3c_tags['single']);
    }

    private function _is_container()
    {
        return in_array($this->_current_tag,
                        $this->_w3c_tags['container']);
    }

    private function _is_deprecated()
    {
        if (in_array($this->_current_tag,
                     $this->_w3c_tags['deprecated']))
        {
            if (ALLOW_DEPRECATED_HTML_TAGS)
            {
                return true;
            }
            else
            {
                uiMessage::render("tried to render deprecated tag '" . $this->_current_tag . "'!",
                                  'warning'); // TODO: automatic "!" on warning? etc.
            }
        }

        return false;
    }

    private function _validate_tag()
    {
        return ((ALLOW_DEPRECATED_TAGS && $this->_is_deprecated())
            || ((!$this->_is_deprecated())
            	&& ($this->_is_single() || $this->_is_container())));
    }

    private function _set_attributes($tag_attributes)
    {
    	$this->_tag_attributes = $tag_attributes;

    	$attributes_string = '';

    	foreach ($tag_attributes as $key => $value)
    	{
    		$attributes_string .= " " . trim(strtolower($key)) . "=\"";

    		if (is_array($value))
    		{
    			$attributes_string .= implode(" ",
    			                              $value);
    		}
    		else
    		{
    			$attributes_string .= $value;
    		}

    		$attributes_string .= "\"";
    	}

    	$this->_tag_html = str_replace("__ATTRIBUTES__",
    	                               $attributes_string,
    	                               $this->_tag_html);
    }

    private function _set_content($tag_content = '')
    {
    	$this->_tag_content = $tag_content;

    	$this->_tag_html = str_replace("__CONTENT__",
    	                               $this->_tag_content,
    	                               $this->_tag_html);
    }

    function __construct($w3c_tag,
                         $tag_attributes,
                         $tag_content)
    {
    	$this->_current_tag = trim(strtolower($w3c_tag));

    	if (!$this->_validate_tag())
        {
            uiMessage::render(strtoupper(__CLASS__) . " tag '" . $this->_current_tag . "' not allowed!",
                              'error');
        }

        $this->_tag_html .= "<" . $this->_current_tag . "__ATTRIBUTES__";

        if ($this->_is_single())
        {
            $this->_tag_html .= " /";
        }
        else
        {
            $this->_tag_html .= ">";

            if ($this->_is_container())
            {
                $this->_tag_html .= "__CONTENT__";
            }

            $this->_tag_html .= "</" . $this->_current_tag;
        }

        $this->_tag_html .= ">\n";

        $this->_set_attributes($tag_attributes);

        if ($this->_is_container($this->_current_tag))
        {
            $this->_set_content($tag_content);
        }
    }

    public function get_html()
    {
    	return $this->_tag_html;
    }

    public function print_html()
    {
    	echo $this->get_html();
    }

    public static function render($args_array)
    {
    	$tag_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                        $args_array['attributes']);

    	$self = new self($args_array['tag'],
    	                 $tag_attributes,
    	                 $args_array['content']);

    	$self->print_html;
    }

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>