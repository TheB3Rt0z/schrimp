<?php

class wraps_ui_widgets extends wraps_ui
{
	private static $_widgets_counter = array
	(
		'titledDiv' => 0,
		'windowDiv' => 0,
	);

	public static function titledDiv($div_title,
	                                 $div_content = '',
	                                 $tag_attributes = array(),
	                                 $tag_id = false)
	{
		$args_array = array
		(
			'title' => $div_title,
			'content' => $div_content,
			'attributes' => $tag_attributes,
			'id' => parent::check_id($tag_id,
			                         __FUNCTION__,
			                         self::$_widgets_counter)
		);

		titledDiv::render($args_array);
	}

	public static function windowDiv($div_title,
	                                 $div_content = '',
	                                 $tag_attributes = array(),
	                                 $tag_id = false,
	                                 $show_exit = false,
	                                 $show_toggle = true)
	{
		$tag_attributes['id'] = parent::check_id($tag_id,
		                                         __FUNCTION__,
		                                         self::$_widgets_counter);

		$args_array = array
		(
			'title' => $div_title,
			'content' => $div_content,
			'attributes' => $tag_attributes,
			'exit' => $show_exit,
			'toggle' => $show_toggle,
		);

		windowDiv::render($args_array);
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'wraps_ui')
	{
		tests::public_method_counter_exists($class_name,
						       		        self::$_widgets_counter);

		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>