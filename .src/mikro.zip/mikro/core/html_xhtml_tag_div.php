<?php

class html_xhtml_tag_div extends html_xhtml_tag
{
	public function __construct($div_attributes,
                                $content_html)
    {
    	parent::__construct('div',
    	                    $div_attributes,
    	                    $content_html);
    }

	public static function render($args_array)
	{
		$div_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                        $args_array['attributes']);

		$self = new self($div_attributes,
    	                 $args_array['content']);

    	$self->print_html();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml_tag')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>