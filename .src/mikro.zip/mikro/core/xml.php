<?php

class xml
{
	private $_version = XML_VERSION;

	public function print_version()
	{
		echo $this->_version . "\n\r";
	}

	static function auto_test($class_name = __CLASS__,
	                          $parent_class = false)
	{
		return tests::common_class_tests($class_name,
		                                 $parent_class);
	}
}

?>