<?php

class html_xhtml_tag_div_titledDiv extends html_xhtml_tag_div
{
	public function __construct($div_attributes,
	                            $div_title,
                                $div_content)
    {
    	$title_attributes = array
		(
			'class' => array
			(
				'title',
			),
		);
		$title_div = new div($title_attributes, $div_title);

		$content_attributes = array
		(
			'class' => array
			(
				'content',
			),
		);
		$content_div = new div($content_attributes, $div_content);

		$composite_content = $title_div->get_html() . $content_div->get_html();

		parent::__construct($div_attributes,
							$composite_content);
    }

	public static function render($args_array)
	{
		$div_attributes = array_merge_recursive(array('class' => __CLASS__),
		                                        $args_array['attributes']);

		$self = new self($div_attributes,
		                 $args_array['title'],
    	                 $args_array['content']);

    	$self->print_html();
	}

	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml_tag_div')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>