<?php

class html_xhtml_dhtml extends html_xhtml
{
	static function auto_test($class_name = __CLASS__,
                              $parent_class = 'html_xhtml')
	{
		return parent::auto_test($class_name,
                                 $parent_class);
	}
}

?>