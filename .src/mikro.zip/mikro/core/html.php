<?php

// TODO: fare in modo che ogni css che inizia con 'nome' sia caricato

class html
{
	private $_predefined_doctype = HTML_DOCTYPE;

	private $_w3c_media = array
    (
        'all',
        'aural',
        'braille',
        'handheld',
        'print',
        'projection',
        'screen',
        'tty',
		'tv',
    );

    private $_w3c_script_mime_types = array
    (
    	'text/plain',
		'text/javascript',
		'text/ecmascript',
		'text/vbscript',
        'application/ecmascript',
        'application/javascript',
    );

    private $_semantic_types = array
    (
    	'bradcrumb',
    	'content',
    	'footer',
		'header',
		'infobar',
    	'navigation',
    	'sidebar',
    );

    private function _is_media_allowed($w3c_media)
    {
        return in_array($w3c_media,
                        $this->_w3c_media);
    }

    private function _is_script_type_allowed($mime_type)
    {
        return in_array($mime_type,
                        $this->_w3c_script_mime_types);
    }

	public function set_doctype($doctype_string)
	{
		$this->_predefined_doctype = $doctype_string;
	}

	public function get_doctype()
	{
		return $this->_predefined_doctype;
	}

	public function print_doctype()
	{
		echo $this->_predefined_doctype . "\n\r";
	}

	public function load_stylesheets($href_path,
	                                 $w3c_media = false)
	{
		$args_array = array
		(
			'attributes' => array
			(
				'href' => STYL_PATH . trim($href_path) . '.css',
				'rel' => 'stylesheet',
				'type' => 'text/css',
			),
		);

		if ($this->_is_media_allowed($w3c_media))
		{
			$args_array['attributes']['media'] = $w3c_media;
		}

		link::render($args_array);
	}

	public function load_favicon($href_path)
	{
		$mime_type = finfo_file(finfo_open(FILEINFO_MIME_TYPE),
		                        STYL_PATH . trim($href_path) . '.ico');

		$args_array = array
		(
			'attributes' => array
			(
				'href' => STYL_PATH . trim($href_path) . '.ico',
				'rel' => 'icon',
				'type' => $mime_type,
			),
		);

		link::render($args_array);
	}

	public function add_script($mime_type,
	                           $content_code)
	{
		if ($this->_is_script_type_allowed($mime_type))
		{
			$args_array = array
			(
				'attributes' => array
				(
					'type' => $mime_type,
				),
				'content' => $content_code,
			);
		}
		else
		{
			// TODO: messaggio di errore con logging
		}

		script::render($args_array);
	}

	public function add_external_resource($src_path)
	{
		if (file_exists($full_path = EXTS_PATH . $src_path))
		{
			$mime_type = finfo_file(finfo_open(FILEINFO_MIME_TYPE),
		                            $full_path);

		    if ($this->_is_script_type_allowed($mime_type))
		    {
		    	$args_array = array
		    	(
		    		'attributes' => array
					(
						'src' => $full_path,
		    		),
		    		'content' => '',
		    	);

		    	// FIXME: quando il type è plain poi lo script non va, allora via!
		    	if ($mime_type != 'text/plain')
		    	{
		    		$args_array['attributes']['type'] = $mime_type;
		    	}

		    	script::render($args_array);
		    }
		}
		else
		{
			// TODO: errore con messaggio e logging
		}
	}

	public function semantic_div($semantic_type)
	{
		// TODO: aggiungere check singletone tipo semantico

		$args_array = array
		(
			'content' => "__" . strtoupper($semantic_type) . "__",
			'attributes' => array
			(
				'id' => $semantic_type,
			),
		);

		div::render($args_array);
	}

	static function auto_test($class_name = __CLASS__,
	                          $parent_class = false)
	{
		return tests::common_class_tests($class_name,
		                                 $parent_class);
	}
}

?>